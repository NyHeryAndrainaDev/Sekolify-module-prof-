// =====================================================================
//  Sekolify Prof — application mobile des professeurs  (v3)
//  • Le PC est trouvé automatiquement sur le Wi-Fi (pas d'adresse IP à saisir)
//  • Nouveau téléphone : port affiché sur le PC + validation par l'administration
//  • Téléphone déjà validé : reconnexion automatique, même si le port a changé
//  • Navigation : Classes > Période > Élèves (DS 1..n + Examen) + Emploi du temps
// =====================================================================

const DISCOVERY_PORT = 47831;      // port FIXE du PC (ne donne que l'adresse ; le port principal change)
const PREFIXES = ["192.168.43", "192.168.1", "192.168.0", "192.168.8", "192.168.100", "192.168.2",
                  "192.168.137", "10.0.0", "10.0.1", "172.20.10", "192.168.10", "192.168.3"];

// --- ÉTAT ---
let serverUrl = "";               // http://ip:port (port principal, change à chaque lancement du PC)
let teacherData = null;           // { classes, timetable, config, grades }
let nav = { cls: null, period: null, cs: null };
let baseGrades = {};              // notes connues du serveur  { clé: valeur }
let dirty = {};                   // modifications non envoyées { clé: {entrée} }
let offlineMode = false;
let connectBusy = false;
let reconnectPromise = null;
let pendingTimer = null;
let pendingFails = 0;
let timetableDay = 0;

// --- PRÉSENCES (état) ---
let attDirty = {};                // appels validés mais pas encore envoyés { "classe|date|heure": {...} }
let attBase = {};                 // appels déjà connus du PC (aujourd'hui) { clé: { id_élève: {status, note} } }
let attDraft = null;              // appel en cours de saisie
let attSyncing = false;
let clockOffset = 0;              // écart (ms) entre l'heure du PC et celle du téléphone

const ATT_STATUSES = [
    { code: "PRESENT", label: "Présent", icon: "check" },
    { code: "ABSENT", label: "Absent", icon: "x" },
    { code: "RETARD", label: "Retard", icon: "clock" },
    { code: "EXCUSE", label: "Excusé", icon: "file-check" },
];

const DEFAULT_CONFIG = {
    school_name: "Sekolify", period_system: "TRIMESTRE", period_count: 3,
    ds_per_period: 3, weight_ds: 1, weight_exam: 2, max_score: 20
};
const DAY_NAMES = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

// --- OUTILS ---
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function lsGet(key, fallback = null) {
    try { const v = localStorage.getItem(key); return v === null ? fallback : JSON.parse(v); } catch (e) { return fallback; }
}
function lsSet(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* ignoré */ } }
function lsDel(...keys) { keys.forEach(k => { try { localStorage.removeItem(k); } catch (e) { /* ignoré */ } }); }

function cfg() { return Object.assign({}, DEFAULT_CONFIG, (teacherData && teacherData.config) || {}); }
function periodLabel(p) { return (cfg().period_system === "BIMESTRE" ? "Bimestre " : "Trimestre ") + p; }
const gkey = (cs, st, period, type, index) => `${cs}|${st}|${period}|${type}|${index}`;
const dsIndexes = () => Array.from({ length: Math.max(1, cfg().ds_per_period) }, (_, i) => i + 1);

let toastTimer;
function showToast(msg) {
    const t = $("toast");
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 3200);
}

function deviceId() {
    let id = lsGet("sekolify_device_id");
    if (!id) {
        id = (window.crypto && crypto.randomUUID) ? crypto.randomUUID()
            : Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
        lsSet("sekolify_device_id", id);
    }
    return id;
}
function deviceName() {
    const m = /;\s*([^;)]+?)\s+Build\//.exec(navigator.userAgent || "");
    return m ? m[1] : "Téléphone Android";
}

// --- NAVIGATION (le bouton Retour d'Android fonctionne) ---
const CONTENT_VIEWS = ["view-classes", "view-periods", "view-notes", "view-attendance"];
function show(viewId) {
    document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
    $(viewId).classList.add("active");
    $(viewId).scrollTop = 0;
}
function go(viewId) { history.pushState({ view: viewId }, ""); show(viewId); }
function goRoot(viewId) { history.replaceState({ view: viewId }, ""); show(viewId); }
function inContent() { return CONTENT_VIEWS.some(v => $(v).classList.contains("active")); }
function rootView() { return lsGet("sekolify_token") && teacherData ? "view-classes" : "view-login"; }

window.addEventListener("popstate", e => {
    let v = (e.state && e.state.view) || rootView();
    if (v === "view-attendance" && !attDraft) v = "view-classes";      // pas d'appel en cours : retour à la liste
    if (v === "view-attendance") renderAttendanceView();
    if (v === "view-periods") renderPeriods();
    if (v === "view-notes") renderNotesView();
    if (v === "view-classes") renderClasses();
    show(v);
});

// =====================================================================
//  RÉSEAU
// =====================================================================

// Requête HTTP avec vrai délai d'attente (plugin natif Capacitor si disponible, sinon fetch)
async function httpRequest(method, url, body, timeout = 8000, headers = {}) {
    const h = Object.assign(body !== undefined ? { "Content-Type": "application/json" } : {}, headers);
    const cap = window.Capacitor;
    const nativeHttp = cap && cap.Plugins && cap.Plugins.CapacitorHttp;
    if (nativeHttp && nativeHttp.request) {
        const r = await nativeHttp.request({ url, method, headers: h, data: body, connectTimeout: timeout, readTimeout: timeout, responseType: "json" });
        let data = r.data;
        if (typeof data === "string") { try { data = JSON.parse(data); } catch (e) { /* texte brut */ } }
        return { status: r.status, data };
    }
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), timeout);
    try {
        const res = await fetch(url, { method, headers: h, body: body !== undefined ? JSON.stringify(body) : undefined, signal: ctl.signal });
        let data = null;
        try { data = await res.json(); } catch (e) { /* pas de JSON */ }
        return { status: res.status, data };
    } finally { clearTimeout(timer); }
}

// Appel de l'API principale (avec jeton). Si le PC a été relancé (nouveau port), on le retrouve tout seul.
async function rawApi(method, path, body, timeout) {
    const token = lsGet("sekolify_token");
    return httpRequest(method, `${serverUrl}${path}`, body, timeout || 10000, token ? { Authorization: `Bearer ${token}` } : {});
}
async function api(method, path, body, timeout) {
    try {
        return await rawApi(method, path, body, timeout);
    } catch (err) {
        if (!lsGet("sekolify_token")) throw err;
        await reconnectSilently();            // lève une erreur si le PC reste introuvable
        return await rawApi(method, path, body, timeout);
    }
}

// --- Recherche du PC sur le Wi-Fi ---
async function probe(ip, timeout = 700) {
    try {
        const r = await httpRequest("GET", `http://${ip}:${DISCOVERY_PORT}/hello`, undefined, timeout);
        if (r.status === 200 && r.data && r.data.app === "sekolify") return r.data;
    } catch (e) { /* pas de PC ici */ }
    return null;
}

function getLocalIPv4s(timeout = 1200) {
    return new Promise(resolve => {
        const ips = new Set();
        let pc, finished = false;
        const done = () => { if (finished) return; finished = true; try { pc && pc.close(); } catch (e) { /* ok */ } resolve([...ips]); };
        try { pc = new RTCPeerConnection({ iceServers: [] }); } catch (e) { return resolve([]); }
        pc.createDataChannel("x");
        pc.onicecandidate = ev => {
            if (!ev.candidate) return done();
            const m = /\b((?:10|192\.168|172\.(?:1[6-9]|2\d|3[01]))(?:\.\d{1,3}){2,3})\b/.exec(ev.candidate.candidate);
            if (m) ips.add(m[1]);
        };
        pc.createOffer().then(o => pc.setLocalDescription(o)).catch(done);
        setTimeout(done, timeout);
    });
}

async function scanPrefix(prefix, onProgress) {
    let found = null, next = 1;
    const worker = async () => {
        while (!found && next <= 254) {
            const n = next++;
            const ip = `${prefix}.${n}`;
            const r = await probe(ip, 600);
            if (r && !found) found = ip;
        }
    };
    if (onProgress) onProgress(prefix);
    await Promise.all(Array.from({ length: 48 }, worker));
    return found;
}

// Renvoie l'adresse IP du PC, ou null si aucun PC Sekolify n'est joignable
async function findPC(onProgress) {
    // NB : on ne teste volontairement PAS navigator.onLine. Quand le téléphone est lui-même le point d'accès
    // (partage de connexion) sans données mobiles, Android déclare « aucun réseau actif » alors que le
    // réseau local fonctionne très bien. On tente donc directement la recherche du PC.

    const last = lsGet("sekolify_ip");
    if (last && await probe(last, 1200)) return last;

    const manual = lsGet("sekolify_ip_manual");
    if (manual && manual !== last && await probe(manual, 1200)) return manual;

    const mine = await getLocalIPv4s();
    const myPrefixes = [...new Set(mine.map(ip => ip.split(".").slice(0, 3).join(".")))];
    const prefixes = myPrefixes.length ? myPrefixes : PREFIXES;     // si on connaît notre sous-réseau, inutile de chercher ailleurs

    for (const p of prefixes) {
        const ip = await scanPrefix(p, onProgress);
        if (ip) return ip;
    }
    return null;
}

function connectError(kind, message) { const e = new Error(message || kind); e.kind = kind; return e; }

// Téléphone déjà validé : trouve le PC puis demande le port ACTUEL grâce au jeton
async function locateServer(onProgress) {
    const token = lsGet("sekolify_token");
    const ip = await findPC(onProgress);
    if (!ip) throw connectError("nopc");
    let r;
    try { r = await httpRequest("POST", `http://${ip}:${DISCOVERY_PORT}/resolve`, { token }, 5000); }
    catch (e) { throw connectError("nopc"); }
    if (r.status === 403 && r.data && r.data.code === "PREMIUM_REQUIRED") throw connectError("premium", r.data.error);
    if (r.status === 403) throw connectError("revoked");
    if (r.status !== 200 || !r.data || !r.data.port) throw connectError("nopc");
    lsSet("sekolify_ip", ip);
    return `http://${ip}:${r.data.port}`;
}

function reconnectSilently() {
    if (!reconnectPromise) {
        reconnectPromise = locateServer().then(url => { serverUrl = url; })
            .finally(() => { reconnectPromise = null; });
    }
    return reconnectPromise;
}

const NONET_MSG = "Aucune connexion réseau : activez le Wi-Fi et connectez-vous au même réseau que le PC.";
const NOPC_MSG = "Impossible de joindre le PC. Vérifiez que le logiciel Sekolify est lancé, que vous êtes sur le même Wi-Fi que le PC, et que le pare-feu Windows l'autorise.";

// =====================================================================
//  DÉMARRAGE
// =====================================================================
document.addEventListener("DOMContentLoaded", () => {
    $("input-port").value = "";
    $("input-username").value = lsGet("sekolify_user", "") || "";
    dirty = lsGet("sekolify_dirty", {}) || {};
    attDirty = lsGet("sekolify_att_dirty", {}) || {};
    clockOffset = lsGet("sekolify_clock_offset", 0) || 0;
    // l'écran « Appel » suit l'heure : mise à jour toutes les 30 s
    setInterval(() => {
        if ($("view-classes").classList.contains("active") && !$("attendance-panel").hidden) renderAttendanceHome();
    }, 30000);
    timetableDay = todayIndex();
    setTab(lsGet("sekolify_tab", "classes"), true);

    const token = lsGet("sekolify_token");
    const pend = lsGet("sekolify_pending");
    const cached = lsGet("sekolify_data");

    if (token) {
        if (cached) {                                   // affichage immédiat, connexion en arrière-plan
            teacherData = cached; indexGrades(); renderClasses(); goRoot("view-classes");
            autoConnect(true);
        } else {
            goRoot("view-connecting"); autoConnect(false);
        }
    } else if (pend) {
        resumePending(pend);
    } else {
        history.replaceState({ view: "view-login" }, "");
    }
});

// --- Connexion automatique (téléphone déjà validé) ---
function setBanner(text, withRetry, kind) {
    $("banner-text").textContent = text;
    $("banner-btn").hidden = !withRetry;
    $("offline-banner").className = "banner" + (kind === "info" ? " info" : "");
    $("offline-banner").hidden = !text;
}

function showConnecting(title, text, failed) {
    $("connecting-title").textContent = title;
    $("connecting-text").textContent = text;
    $("connecting-spinner").hidden = !!failed;
    $("connecting-actions").hidden = !failed;
    $("btn-offline").hidden = !(failed && lsGet("sekolify_data"));
    if (!$("view-connecting").classList.contains("active")) goRoot("view-connecting");
}

async function autoConnect(background) {
    if (connectBusy) return;
    connectBusy = true;
    if (background) setBanner("🔎 Connexion au PC en cours…", false, "info");
    else showConnecting("Connexion au PC…", "Recherche du PC sur le Wi-Fi", false);
    try {
        serverUrl = await locateServer(p => {
            if (!background) $("connecting-text").textContent = `Recherche du PC sur le Wi-Fi… (${p}.x)`;
        });
        offlineMode = false;
        setBanner("", false);
        await fetchTeacherData(true);
    } catch (err) {
        handleConnectError(err, background);
    } finally {
        connectBusy = false;
    }
}

function handleConnectError(err, background) {
    if (err.kind === "revoked") { sessionExpired(); return; }
    const msg = err.kind === "nonet" ? NONET_MSG : err.kind === "premium" ? err.message : NOPC_MSG;
    const title = err.kind === "premium" ? "Fonction non disponible" : err.kind === "nonet" ? "Pas de réseau" : "PC introuvable";
    if (window.SekNotif) SekNotif.onOffline();
    if (background && lsGet("sekolify_data")) {
        offlineMode = true;
        renderClasses();
        setBanner("📴 " + (err.kind === "nonet" ? "Pas de réseau" : err.kind === "premium" ? "Licence non Premium" : "PC introuvable") + " — mode hors-ligne", true);
        showToast(msg);
    } else {
        showConnecting(title, msg, true);
    }
}

function retryConnect() {
    const background = !!(lsGet("sekolify_data") && inContent());
    autoConnect(background);
}

function continueOffline() {
    teacherData = lsGet("sekolify_data");
    if (!teacherData) return;
    offlineMode = true; indexGrades(); renderClasses();
    setBanner("📴 Mode hors-ligne : données enregistrées sur le téléphone", true);
    goRoot("view-classes");
}

// --- Connexion d'un NOUVEAU téléphone ---
function showManualIp() { $("manual-ip-group").hidden = false; $("btn-manual-ip").hidden = true; $("input-ip-manual").focus(); }

async function login(ev) {
    if (ev) ev.preventDefault();
    const port = parseInt($("input-port").value.trim(), 10);
    const username = $("input-username").value.trim();
    const code = $("input-code").value.trim();
    const btn = $("btn-login"), errorMsg = $("login-error");
    errorMsg.textContent = "";

    if (!port || port < 1024 || port > 65535) { errorMsg.textContent = "Entrez le port affiché sur le PC (menu « Application mobile »)."; return; }
    if (!username || !code) { errorMsg.textContent = "Veuillez remplir l'identifiant et le code d'accès."; return; }

    btn.disabled = true; btn.textContent = "Recherche du PC…";
    try {
        // 1) adresse du PC : automatique (ou saisie manuelle en dernier recours)
        const manual = $("input-ip-manual").value.trim();
        let ip;
        if (manual) { lsSet("sekolify_ip_manual", manual); ip = manual; }
        else ip = await findPC(p => { btn.textContent = `Recherche du PC… (${p}.x)`; });
        if (!ip) { errorMsg.textContent = NOPC_MSG; $("btn-manual-ip").hidden = false; return; }
        lsSet("sekolify_ip", ip);

        // 2) demande de connexion
        btn.textContent = "Connexion…";
        serverUrl = `http://${ip}:${port}`;
        let r;
        try {
            r = await httpRequest("POST", `${serverUrl}/api/login`,
                { username, access_code: code, device_id: deviceId(), device_name: deviceName() }, 8000);
        } catch (e) {
            errorMsg.textContent = "Port incorrect ou PC injoignable. Vérifiez le port affiché sur le PC.";
            return;
        }
        const data = r.data || {};
        if (r.status === 200 && data.status === "approved") { await finishLogin(data, username); return; }
        if (r.status === 202 && data.status === "pending") { startPending({ server: serverUrl, request_secret: data.request_secret, username, device_id: deviceId() }); return; }
        errorMsg.textContent = data.error || "Connexion refusée par le PC.";
    } catch (err) {
        errorMsg.textContent = err.kind === "nonet" ? NONET_MSG : (err.message || "Erreur de connexion.");
    } finally {
        btn.disabled = false; btn.textContent = "Se connecter";
    }
}

async function finishLogin(data, username) {
    if (lsGet("sekolify_user") && lsGet("sekolify_user") !== username) { dirty = {}; attDirty = {}; lsDel("sekolify_dirty", "sekolify_data", "sekolify_att_dirty", "sekolify_att_draft"); }
    lsSet("sekolify_token", data.token);
    lsSet("sekolify_user", username);
    lsSet("sekolify_teacher_name", data.teacher_name || username);
    lsSet("sekolify_school_name", data.school_name || "");
    lsDel("sekolify_pending");
    clearTimeout(pendingTimer);
    $("input-code").value = "";
    await fetchTeacherData(false);
}

// --- Attente de validation par l'administration ---
function startPending(p) {
    lsSet("sekolify_pending", p);
    pendingFails = 0;
    $("pending-info").innerHTML = `<strong>${esc(p.username)}</strong> · ${esc(deviceName())}`;
    $("pending-status").textContent = "En attente de validation…";
    goRoot("view-pending");
    pollPending();
}

function resumePending(p) {
    serverUrl = p.server;
    startPending(p);
}

async function pollPending() {
    clearTimeout(pendingTimer);
    const p = lsGet("sekolify_pending");
    if (!p) return;
    try {
        const r = await httpRequest("POST", `${p.server}/api/login/status`, { device_id: p.device_id, request_secret: p.request_secret }, 6000);
        pendingFails = 0;
        const d = r.data || {};
        if (r.status === 200 && d.status === "approved") { serverUrl = p.server; await finishLogin(d, p.username); return; }
        if (r.status === 200 && d.status === "rejected") { endPending("Votre demande a été refusée par l'administration."); return; }
        if (r.status === 404 || r.status === 403) { endPending(d.error || "Demande introuvable : recommencez."); return; }
        $("pending-status").textContent = "En attente de validation…";
    } catch (e) {
        pendingFails++;
        $("pending-status").textContent = "Connexion au PC perdue… nouvelle tentative";
        if (pendingFails >= 8) { endPending("Le PC ne répond plus (il a peut-être été relancé : le port a changé). Refaites la demande avec le nouveau port."); return; }
    }
    pendingTimer = setTimeout(pollPending, 3000);
}

function endPending(message) {
    clearTimeout(pendingTimer);
    lsDel("sekolify_pending");
    $("login-error").textContent = message;
    goRoot("view-login");
}
function cancelPending() { endPending(""); }

// --- DONNÉES ---
async function fetchTeacherData(silent) {
    try {
        const response = await api("GET", "/api/mes-donnees");
        if (response.status === 401) { sessionExpired(); return; }
        if (response.status === 403) {
            const msg = (response.data && response.data.error) || "Accès refusé.";
            if (lsGet("sekolify_data")) { offlineMode = true; setBanner("🔒 " + msg, false); showToast(msg); renderClasses(); if (!inContent()) goRoot("view-classes"); }
            else showConnecting("Fonction non disponible", msg, true);
            return;
        }
        if (response.status !== 200 || !response.data) throw new Error("Erreur serveur");

        teacherData = response.data;
        lsSet("sekolify_data", teacherData);
        offlineMode = false;
        attOnData();                      // horloge du PC + appels déjà enregistrés
        setBanner("", false);
        indexGrades();
        relinkNav();
        renderClasses();
        if (!inContent()) goRoot("view-classes");
        else if ($("view-attendance").classList.contains("active")) { /* appel en cours : on ne touche à rien */ }
        else if ($("view-notes").classList.contains("active")) renderNotesView();
        else if ($("view-periods").classList.contains("active")) renderPeriods();
        if (window.SekNotif) SekNotif.onConnected(teacherData, pendingCount());   // notifications
        if (!silent) showToast("Connexion réussie !");
    } catch (err) {
        const cached = teacherData || lsGet("sekolify_data");
        if (cached) {
            teacherData = cached; offlineMode = true; indexGrades(); renderClasses();
            if (window.SekNotif) SekNotif.onOffline();
            setBanner("📴 PC introuvable — mode hors-ligne", true);
            if (!inContent()) goRoot("view-classes");
            showToast(err.kind === "nonet" ? NONET_MSG : "PC injoignable : mode hors-ligne");
        } else {
            handleConnectError(err.kind ? err : connectError("nopc"), false);
        }
    }
}

// après une actualisation, rattache la classe/matière ouvertes aux nouveaux objets
function relinkNav() {
    if (!teacherData || !nav.cls) return;
    const cls = teacherData.classes.find(c => c.id === nav.cls.id);
    if (!cls) { nav = { cls: null, period: null, cs: null }; return; }
    nav.cls = cls;
    nav.cs = (nav.cs && cls.subjects.find(s => s.class_subject_id === nav.cs.class_subject_id)) || cls.subjects[0] || null;
}

async function refreshData() {
    if (pendingCount() > 0) showToast("Pensez à envoyer vos notes (ouvrez une classe).");
    else showToast("Actualisation…");
    await autoConnect(true);
    if (!offlineMode) showToast("Données à jour ✔");
}

function sessionExpired() {
    lsDel("sekolify_token");
    clearTimeout(pendingTimer);
    $("login-error").textContent = "Accès retiré ou expiré. Refaites une demande de connexion (vos notes et appels non envoyés sont conservés).";
    goRoot("view-login");
}

function logout() {
    const n = pendingCount();
    if (n > 0 && !confirm(`${n} note(s) n'ont pas été envoyées au PC. Se déconnecter les supprimera. Continuer ?`)) return;
    const na = Object.keys(attDirty).length;
    if (na > 0 && !confirm(`${na} appel(s) de présence n'ont pas été envoyés au PC. Se déconnecter les supprimera. Continuer ?`)) return;
    lsDel("sekolify_token", "sekolify_data", "sekolify_dirty", "sekolify_teacher_name", "sekolify_school_name", "sekolify_pending",
        "sekolify_att_dirty", "sekolify_att_draft", "sekolify_clock_offset");
    attDirty = {}; attBase = {}; attDraft = null; clockOffset = 0;
    dirty = {}; baseGrades = {}; teacherData = null; nav = { cls: null, period: null, cs: null };
    if (window.SekNotif) SekNotif.onLogout();
    setBanner("", false);
    $("login-error").textContent = "";
    goRoot("view-login");
}

function indexGrades() {
    baseGrades = {};
    ((teacherData && teacherData.grades) || []).forEach(g => {
        baseGrades[gkey(g.class_subject_id, g.student_id, g.period, g.type, g.index)] = g.value;
    });
    attIndexBase();
}

// --- ACCÈS AUX NOTES ---
function getValue(key) {
    if (key in dirty) return dirty[key].value;
    return key in baseGrades ? baseGrades[key] : null;
}
function pendingCount() { return Object.keys(dirty).length; }

function setValue(entry, value) {
    const key = gkey(entry.class_subject_id, entry.student_id, entry.period, entry.type, entry.index);
    const base = key in baseGrades ? baseGrades[key] : null;
    if (value === base) delete dirty[key];
    else dirty[key] = Object.assign({}, entry, { value });
    lsSet("sekolify_dirty", dirty);
}

// --- ONGLETS : CLASSES / EMPLOI DU TEMPS ---
function setTab(tab, silent) {
    if (tab !== "classes" && tab !== "timetable" && tab !== "attendance") tab = "classes";
    $("tab-classes").classList.toggle("active", tab === "classes");
    $("tab-timetable").classList.toggle("active", tab === "timetable");
    $("tab-attendance").classList.toggle("active", tab === "attendance");
    $("classes-list").hidden = tab !== "classes";
    $("timetable-panel").hidden = tab !== "timetable";
    $("attendance-panel").hidden = tab !== "attendance";
    lsSet("sekolify_tab", tab);
    if (tab === "timetable" && !silent) renderTimetable();
    if (tab === "attendance" && !silent) renderAttendanceHome();
}

// --- EMPLOI DU TEMPS ---
function todayIndex() {
    const d = new Date().getDay();            // 0 = dimanche
    return d === 0 ? 0 : d - 1;               // dimanche -> lundi
}
const hh = h => String(h).padStart(2, "0") + ":00";

// fusionne les heures consécutives d'une même classe/matière : 8h+9h => 08:00 – 10:00
function mergedSlots(day) {
    const slots = ((teacherData && teacherData.timetable) || []).filter(s => s.day === day).sort((a, b) => a.hour - b.hour);
    const out = [];
    slots.forEach(s => {
        const last = out[out.length - 1];
        if (last && last.class_name === s.class_name && last.subject_name === s.subject_name && last.end === s.hour) last.end = s.hour + 1;
        else out.push({ class_name: s.class_name, subject_name: s.subject_name, start: s.hour, end: s.hour + 1 });
    });
    return out;
}

function renderTimetable() {
    const all = (teacherData && teacherData.timetable) || [];
    const pills = $("day-pills");
    pills.innerHTML = "";
    const today = todayIndex();
    DAY_NAMES.forEach((name, i) => {
        const hours = all.filter(s => s.day === i).length;
        const b = document.createElement("button");
        b.className = "day-pill" + (i === timetableDay ? " active" : "") + (i === today ? " today" : "");
        b.innerHTML = `<b>${name.slice(0, 3)}</b><small>${hours ? hours + " h" : "—"}</small>`;
        b.onclick = () => { timetableDay = i; renderTimetable(); };
        pills.appendChild(b);
    });

    const list = $("slots-list");
    if (!all.length) {
        list.innerHTML = "<p class='empty'>Aucun créneau pour le moment.<br>L'administration n'a pas encore renseigné votre emploi du temps.</p>";
        return;
    }
    const slots = mergedSlots(timetableDay);
    if (!slots.length) { list.innerHTML = `<p class='empty'>Aucun cours ce ${DAY_NAMES[timetableDay].toLowerCase()} 🎉</p>`; return; }

    const now = new Date(), nowH = now.getHours() + now.getMinutes() / 60;
    const total = slots.reduce((a, s) => a + (s.end - s.start), 0);
    list.innerHTML = `<div class="day-summary">${DAY_NAMES[timetableDay]} · ${total} h de cours · ${slots.length} séance(s)</div>` +
        slots.map(s => {
            const isNow = timetableDay === today && nowH >= s.start && nowH < s.end;
            return `<div class="slot-card${isNow ? " now" : ""}">
                <div class="slot-time">${hh(s.start)}<small>${hh(s.end)}</small></div>
                <div class="slot-main">
                    ${isNow ? '<span class="slot-now">EN COURS</span>' : ""}
                    <div class="slot-subject">${esc(s.subject_name)}</div>
                    <span class="slot-class">${esc(s.class_name)}</span>
                </div>
            </div>`;
        }).join("");
}

// --- VUE : CLASSES ---
function renderClasses() {
    $("classes-title").textContent = lsGet("sekolify_teacher_name", "Mes classes");
    $("classes-sub").textContent = (lsGet("sekolify_school_name") || cfg().school_name || "");

    renderTimetable();
    renderAttendanceHome();
    const container = $("classes-list");
    if (!teacherData || !teacherData.classes || !teacherData.classes.length) {
        container.innerHTML = "<p class='empty'>Aucune classe assignée.<br>Demandez à l'administration d'associer vos matières.</p>";
        return;
    }
    container.innerHTML = "";
    teacherData.classes.forEach(cls => {
        const pend = classPending(cls);
        const div = document.createElement("div");
        div.className = "list-item";
        div.onclick = () => openClass(cls);
        div.innerHTML = `
            <div class="badge-circle">${esc(cls.name.slice(0, 3))}</div>
            <div class="list-main">
                <div class="list-item-title">${esc(cls.name)}</div>
                <div class="list-item-sub">${cls.students.length} élève(s) · ${esc(cls.subjects.map(s => s.name).join(", "))}</div>
            </div>
            ${pend ? `<span class="pending-pill">${pend}</span>` : ""}
            <span class="chev">›</span>`;
        container.appendChild(div);
    });
}

function classPending(cls) {
    const ids = new Set(cls.subjects.map(s => String(s.class_subject_id)));
    return Object.values(dirty).filter(d => ids.has(String(d.class_subject_id))).length;
}

// --- VUE 3 : PÉRIODES ---
function openClass(cls) {
    nav.cls = cls;
    nav.cs = cls.subjects[0] || null;
    renderPeriods();
    go("view-periods");
}

function periodProgress(cls, period) {
    const idx = dsIndexes();
    let filled = 0, total = 0;
    cls.subjects.forEach(sub => cls.students.forEach(st => {
        idx.forEach(i => { total++; if (getValue(gkey(sub.class_subject_id, st.id, period, "DS", i)) !== null) filled++; });
        total++; if (getValue(gkey(sub.class_subject_id, st.id, period, "EXAM", 0)) !== null) filled++;
    }));
    return total ? Math.round(filled * 100 / total) : 0;
}

function renderPeriods() {
    const cls = nav.cls;
    if (!cls) return;
    $("periods-title").textContent = cls.name;
    $("periods-sub").textContent = "Choisissez la période";
    const c = cfg();
    const container = $("periods-list");
    container.innerHTML = "";
    for (let p = 1; p <= c.period_count; p++) {
        const pct = periodProgress(cls, p);
        const div = document.createElement("div");
        div.className = "list-item";
        div.onclick = () => openPeriod(p);
        div.innerHTML = `
            <div class="badge-circle">${p}</div>
            <div class="list-main">
                <div class="list-item-title">${periodLabel(p)}</div>
                <div class="list-item-sub">${c.ds_per_period} DS + examen · ${pct}% saisi</div>
                <div class="mini-progress"><div style="width:${pct}%"></div></div>
            </div>
            <span class="chev">›</span>`;
        container.appendChild(div);
    }
}

// --- VUE 4 : SAISIE ---
function openPeriod(p) {
    nav.period = p;
    nav.cs = nav.cs || nav.cls.subjects[0];
    $("search-student").value = "";
    renderNotesView();
    go("view-notes");
}

function renderNotesView() {
    if (!nav.cls || !nav.period) return;
    $("notes-title").textContent = nav.cls.name;
    $("notes-sub").textContent = periodLabel(nav.period);

    const chips = $("subject-chips");
    chips.innerHTML = "";
    chips.hidden = nav.cls.subjects.length === 0;
    nav.cls.subjects.forEach(sub => {
        const b = document.createElement("button");
        b.className = "chip" + (nav.cs && nav.cs.class_subject_id === sub.class_subject_id ? " active" : "");
        b.textContent = sub.name;
        b.onclick = () => { nav.cs = sub; renderNotesView(); };
        chips.appendChild(b);
    });
    renderStudents();
}

function noteEntry(studentId, type, index) {
    return { class_subject_id: nav.cs.class_subject_id, student_id: studentId, period: nav.period, type, index };
}

function renderStudents() {
    const container = $("students-list");
    if (!nav.cs) { container.innerHTML = "<p class='empty'>Aucune matière assignée.</p>"; return; }
    const q = $("search-student").value.trim().toLowerCase();
    const idx = dsIndexes();
    const students = nav.cls.students.filter(s => !q || s.name.toLowerCase().includes(q) || String(s.matricule || "").toLowerCase().includes(q));

    container.innerHTML = "";
    if (!students.length) { container.innerHTML = "<p class='empty'>Aucun élève trouvé.</p>"; updateStatus(); return; }

    students.forEach((st, n) => {
        const row = document.createElement("div");
        row.className = "student-row";
        row.dataset.student = st.id;

        const cells = idx.map(i => cellHtml(st.id, "DS", i, `DS${i}`, false)).join("") + cellHtml(st.id, "EXAM", 0, "EXAMEN", true);
        row.innerHTML = `
            <div class="student-head">
                <div class="student-num">${n + 1}</div>
                <div class="student-info">
                    <div class="student-name">${esc(st.name)}</div>
                    <div class="student-mat">${esc(st.matricule || "")}</div>
                </div>
                <div class="avg" data-avg="${st.id}">–</div>
            </div>
            <div class="note-grid">${cells}</div>`;
        container.appendChild(row);
        updateAvg(st.id);
    });

    container.querySelectorAll(".note-input").forEach(inp => {
        inp.addEventListener("input", onNoteInput);
        inp.addEventListener("focus", () => inp.select());
        inp.addEventListener("keydown", onNoteKey);
    });
    updateStatus();
}

function cellHtml(studentId, type, index, label, isExam) {
    const key = gkey(nav.cs.class_subject_id, studentId, nav.period, type, index);
    const v = getValue(key);
    const cls = "note-input" + (key in dirty ? " dirty" : "");
    return `<div class="note-cell${isExam ? " exam" : ""}">
        <label>${label}</label>
        <input type="text" inputmode="decimal" autocomplete="off" class="${cls}"
               data-st="${studentId}" data-type="${type}" data-index="${index}"
               value="${v === null ? "" : String(v).replace(".", ",")}" placeholder="–" enterkeyhint="next">
    </div>`;
}

function onNoteInput(e) {
    const inp = e.target;
    let raw = inp.value.replace(/[^0-9.,]/g, "");
    if (raw !== inp.value) inp.value = raw;
    const st = Number(inp.dataset.st), type = inp.dataset.type, index = Number(inp.dataset.index);
    const entry = noteEntry(st, type, index);

    if (raw === "") {
        inp.classList.remove("invalid");
        setValue(entry, null);
    } else {
        const num = parseFloat(raw.replace(",", "."));
        const max = cfg().max_score;
        if (isNaN(num) || num < 0 || num > max) { inp.classList.add("invalid"); return; }
        inp.classList.remove("invalid");
        setValue(entry, num);
    }
    const key = gkey(entry.class_subject_id, st, entry.period, type, index);
    inp.classList.toggle("dirty", key in dirty);
    updateAvg(st);
    updateStatus();
}

function onNoteKey(e) {
    if (e.key !== "Enter") return;
    e.preventDefault();
    const all = Array.from(document.querySelectorAll("#students-list .note-input"));
    const next = all[all.indexOf(e.target) + 1];
    if (next) next.focus(); else e.target.blur();
}

function updateAvg(studentId) {
    const el = document.querySelector(`[data-avg="${studentId}"]`);
    if (!el || !nav.cs) return;
    const c = cfg();
    const ds = dsIndexes().map(i => getValue(gkey(nav.cs.class_subject_id, studentId, nav.period, "DS", i))).filter(v => v !== null);
    const exam = getValue(gkey(nav.cs.class_subject_id, studentId, nav.period, "EXAM", 0));
    if (!ds.length && exam === null) { el.textContent = "–"; el.className = "avg"; return; }
    const avgDs = ds.length ? ds.reduce((a, b) => a + b, 0) / ds.length : 0;
    const w = c.weight_ds + c.weight_exam;
    const avg = w > 0 ? (avgDs * c.weight_ds + (exam || 0) * c.weight_exam) / w : 0;
    el.textContent = avg.toFixed(2).replace(".", ",");
    el.className = "avg " + (avg >= c.max_score / 2 ? "good" : "low");
}

function updateStatus() {
    // progression de la matière / période affichée
    if (nav.cs && nav.cls) {
        const idx = dsIndexes();
        let filled = 0, total = 0;
        nav.cls.students.forEach(st => {
            idx.forEach(i => { total++; if (getValue(gkey(nav.cs.class_subject_id, st.id, nav.period, "DS", i)) !== null) filled++; });
            total++; if (getValue(gkey(nav.cs.class_subject_id, st.id, nav.period, "EXAM", 0)) !== null) filled++;
        });
        const pct = total ? Math.round(filled * 100 / total) : 0;
        $("progress-bar").style.width = pct + "%";
        $("progress-text").textContent = `${nav.cs.name} · ${filled}/${total} notes saisies (${pct}%)`;
    }
    const n = pendingCount();
    const t = $("sync-text");
    t.textContent = n ? `${n} modification(s) à envoyer` : "Tout est synchronisé ✔";
    t.className = n ? "pending" : "";
    $("btn-sync").disabled = n === 0;
    if (window.SekNotif) SekNotif.onPending(n);
}

// --- SYNCHRONISATION AVEC LE PC ---
async function syncNotes() {
    const entries = Object.entries(dirty);
    if (!entries.length) { showToast("Rien à envoyer."); return; }
    const btn = $("btn-sync");
    btn.disabled = true; btn.textContent = "Envoi…";

    try {
        const response = await api("POST", "/api/sync-notes", { notes: entries.map(([, e]) => e) }, 20000);
        if (response.status === 401) { sessionExpired(); return; }
        if (response.status === 403) { showToast((response.data && response.data.error) || "Accès refusé."); return; }
        const data = response.data || {};
        if (response.status !== 200) throw new Error(data.error || "Erreur serveur");

        if (data.errors && data.errors.length) {
            showToast(`${data.synced} envoyée(s), ${data.errors.length} erreur(s). Réessayez.`);
        } else {
            entries.forEach(([key, e]) => { baseGrades[key] = e.value; delete dirty[key]; });
            // garde le cache local cohérent avec le serveur
            if (teacherData) {
                teacherData.grades = Object.entries(baseGrades).filter(([, v]) => v !== null).map(([k, v]) => {
                    const [cs, st, period, type, index] = k.split("|");
                    return { class_subject_id: +cs, student_id: +st, period: +period, type, index: +index, value: v };
                });
                lsSet("sekolify_data", teacherData);
            }
            lsSet("sekolify_dirty", dirty);
            showToast(`✔ ${data.synced} note(s) envoyée(s) au PC`);
            document.querySelectorAll(".note-input.dirty").forEach(i => i.classList.remove("dirty"));
        }
    } catch (err) {
        showToast("PC injoignable : vos notes restent enregistrées sur le téléphone.");
    } finally {
        btn.textContent = "Envoyer au PC";
        updateStatus();
    }
}


// =====================================================================
//  PRÉSENCES — appel par créneau d'une heure
//  • Le prof ne peut faire l'appel QUE du cours qu'il a en ce moment (emploi du temps)
//  • Même logique que les notes : saisie hors-ligne, puis envoi au PC
//  • L'heure de référence est celle du PC (écart mémorisé à chaque connexion)
// =====================================================================
const pad2 = n => String(n).padStart(2, "0");
const isoDate = d => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const attKey = (classId, date, hour) => `${classId}|${date}|${hour}`;
function nowAdj() { return new Date(Date.now() + clockOffset); }
function dayIndexOf(d) { const g = d.getDay(); return g === 0 ? 6 : g - 1; }     // 0 = lundi … 5 = samedi, 6 = dimanche (pas de cours)
function attData() { return (teacherData && teacherData.attendance) || null; }
function attRosterOf(classId) { const a = attData(); return (a && a.rosters && a.rosters[String(classId)]) || []; }
function attStatusOf(key) { return key in attDirty ? "pending" : key in attBase ? "done" : "todo"; }

function attSlotsToday() {
    const day = dayIndexOf(nowAdj());
    return ((teacherData && teacherData.timetable) || []).filter(s => s.day === day && s.class_id != null).sort((a, b) => a.hour - b.hour);
}
function attCurrentSlots() { const h = nowAdj().getHours(); return attSlotsToday().filter(s => s.hour === h); }

function attIndexBase() {
    attBase = {};
    const a = attData();
    if (!a) return;
    (a.sessions || []).forEach(sess => {
        const entries = {};
        (sess.rows || []).forEach(r => { entries[r.student_id] = { status: r.status, note: r.note || null }; });
        attBase[attKey(sess.class_id, a.today, sess.hour)] = entries;
    });
}

function attOnData() {
    try {
        const a = attData();
        const m = a && a.server_now ? /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(a.server_now) : null;
        if (m) {
            clockOffset = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]).getTime() - Date.now();
            lsSet("sekolify_clock_offset", clockOffset);
        }
        attIndexBase();
        if (Object.keys(attDirty).length) setTimeout(() => attSync(true), 400);   // le PC répond : on envoie les appels en attente
    } catch (e) { /* ne casse jamais la connexion */ }
}

// --- ONGLET « APPEL » ---
function renderAttendanceHome() {
    const panel = $("attendance-panel");
    if (!panel) return;
    const pendKeys = Object.keys(attDirty);
    const badge = $("att-tab-badge");
    badge.textContent = pendKeys.length;
    badge.hidden = pendKeys.length === 0;
    if (!teacherData) { panel.innerHTML = ""; return; }

    const a = attData();
    const missingIds = ((teacherData.timetable) || []).some(s => s.class_id == null);
    if (!a || missingIds) {
        panel.innerHTML = `<p class="empty">${icon("wifi-off")}La présence n'est pas encore chargée.<br>Connectez-vous au PC (bouton d'actualisation en haut) pour l'activer.</p>`;
        return;
    }

    const now = nowAdj();
    const today = isoDate(now);
    const dayName = DAY_NAMES[dayIndexOf(now)] || "Dimanche";
    let html = `<div class="att-now">${dayName} ${pad2(now.getDate())}/${pad2(now.getMonth() + 1)} · ${pad2(now.getHours())}:${pad2(now.getMinutes())}</div>`;

    const cur = attCurrentSlots();
    if (cur.length) {
        html += cur.map(s => {
            const st = attStatusOf(attKey(s.class_id, today, s.hour));
            const n = attRosterOf(s.class_id).length;
            const chip = st === "pending" ? `<span class="att-chip pend">${icon("clock")}À envoyer au PC</span>`
                : st === "done" ? `<span class="att-chip ok">${icon("check")}Appel enregistré</span>`
                : `<span class="att-chip todo">Appel à faire</span>`;
            return `<div class="att-card">
                <div class="att-card-top">
                    <div class="att-time">${hh(s.hour)}<small>${hh(s.hour + 1)}</small></div>
                    <div class="att-card-main">
                        <div class="att-subject">${esc(s.subject_name)}</div>
                        <span class="slot-class">${esc(s.class_name)}</span><span class="att-count">${n} élève(s)</span>
                    </div>
                </div>
                <div class="att-card-foot">
                    ${chip}
                    <button class="att-go" onclick="openAttendance(${s.class_id}, ${s.hour})" ${n ? "" : "disabled"}>${icon("clipboard-check")}${st === "todo" ? "Faire l'appel" : "Modifier l'appel"}</button>
                </div>
            </div>`;
        }).join("");
    } else {
        const nx = attSlotsToday().find(s => s.hour > now.getHours());
        html += `<div class="att-empty">${icon("clock")}<div><b>Aucun cours en ce moment</b>
            <span>${nx ? "Prochain cours : " + hh(nx.hour) + " · " + esc(nx.class_name) + " · " + esc(nx.subject_name) : "Plus de cours aujourd'hui."}</span></div></div>`;
    }

    if (pendKeys.length) {
        html += `<div class="att-pending">
            <div><b>${pendKeys.length} appel(s) à envoyer</b><span>Envoi automatique dès que le PC est joignable.</span></div>
            <button class="att-go alt" onclick="attSync(false)" ${attSyncing ? "disabled" : ""}>${icon("rotate-cw", attSyncing ? "ic-spin" : "")}${attSyncing ? "Envoi…" : "Envoyer"}</button>
        </div>`;
    }

    const all = attSlotsToday();
    if (all.length) {
        html += `<div class="att-day-title">Vos appels aujourd'hui</div>` + all.map(s => {
            const st = attStatusOf(attKey(s.class_id, today, s.hour));
            const past = s.hour < now.getHours();
            const chip = st === "pending" ? `<span class="att-chip pend">À envoyer</span>`
                : st === "done" ? `<span class="att-chip ok">${icon("check")}Fait</span>`
                : past ? `<span class="att-chip late">Non fait</span>`
                : s.hour === now.getHours() ? `<span class="att-chip todo">En cours</span>`
                : `<span class="att-chip todo">À venir</span>`;
            return `<div class="att-day-row"><b>${hh(s.hour)}</b><span class="att-day-main">${esc(s.class_name)} · ${esc(s.subject_name)}</span>${chip}</div>`;
        }).join("");
    }
    panel.innerHTML = html;
}

// --- ÉCRAN D'APPEL ---
function openAttendance(classId, hour) {
    const slot = attCurrentSlots().find(s => s.class_id === classId && s.hour === hour);
    if (!slot) { showToast("Ce cours n'est plus en cours."); renderAttendanceHome(); return; }
    const roster = attRosterOf(classId);
    if (!roster.length) { showToast("Aucun élève dans cette classe."); return; }

    const date = isoDate(nowAdj());
    const key = attKey(classId, date, hour);
    const saved = key in attDirty ? attDirty[key].entries : (attBase[key] || {});
    const draft = lsGet("sekolify_att_draft");
    const useDraft = !!(draft && draft.key === key && draft.statuses);

    const statuses = {}, notes = {};
    roster.forEach(st => {
        const e = saved[st.id];
        statuses[st.id] = (useDraft && draft.statuses[st.id]) || (e ? e.status : "PRESENT");
        notes[st.id] = e ? (e.note || null) : null;          // la remarque saisie sur PC est conservée
    });
    attDraft = { key, class_id: classId, date, hour, class_name: slot.class_name, subject_name: slot.subject_name, roster, statuses, notes };
    $("att-search").value = "";
    renderAttendanceView();
    go("view-attendance");
}

function renderAttendanceView() {
    const d = attDraft;
    if (!d) return;
    $("att-title").textContent = d.class_name;
    $("att-sub").textContent = `${d.subject_name} · ${hh(d.hour)} – ${hh(d.hour + 1)}`;

    const q = $("att-search").value.trim().toLowerCase();
    const list = $("att-students");
    list.innerHTML = "";
    d.roster.forEach((st, n) => {
        if (q && !st.name.toLowerCase().includes(q) && !String(st.matricule || "").toLowerCase().includes(q)) return;
        const row = document.createElement("div");
        row.className = "att-row";
        row.dataset.st = st.id;
        row.innerHTML = `
            <div class="student-head">
                <div class="student-num">${n + 1}</div>
                <div class="student-info">
                    <div class="student-name">${esc(st.name)}</div>
                    <div class="student-mat">${esc(st.matricule || "")}</div>
                </div>
            </div>
            <div class="att-seg">${ATT_STATUSES.map(s =>
                `<button type="button" class="att-opt s-${s.code}" data-code="${s.code}" onclick="attSet(${st.id}, '${s.code}')">${icon(s.icon)}<span>${s.label}</span></button>`
            ).join("")}</div>`;
        list.appendChild(row);
        attPaintRow(row, d.statuses[st.id]);
    });
    if (!list.children.length) list.innerHTML = "<p class='empty'>Aucun élève trouvé.</p>";
    attUpdateCounters();
}

function attPaintRow(row, code) {
    row.querySelectorAll(".att-opt").forEach(b => b.classList.toggle("on", b.dataset.code === code));
}

function attSet(studentId, code) {
    if (!attDraft) return;
    attDraft.statuses[studentId] = code;
    const row = document.querySelector(`#att-students .att-row[data-st="${studentId}"]`);
    if (row) attPaintRow(row, code);
    attUpdateCounters();
    lsSet("sekolify_att_draft", { key: attDraft.key, statuses: attDraft.statuses });   // survit à un retour accidentel
}

function attAllPresent() {
    if (!attDraft) return;
    attDraft.roster.forEach(st => { attDraft.statuses[st.id] = "PRESENT"; });
    lsSet("sekolify_att_draft", { key: attDraft.key, statuses: attDraft.statuses });
    renderAttendanceView();
}

function attCounts() {
    const c = { PRESENT: 0, ABSENT: 0, RETARD: 0, EXCUSE: 0 };
    if (attDraft) attDraft.roster.forEach(st => { c[attDraft.statuses[st.id]] = (c[attDraft.statuses[st.id]] || 0) + 1; });
    return c;
}

function attUpdateCounters() {
    const c = attCounts();
    ATT_STATUSES.forEach(s => { $("att-c-" + s.code).textContent = c[s.code]; });
    const total = attDraft ? attDraft.roster.length : 0;
    $("att-bar-text").textContent = `${total} élève(s) · ${c.ABSENT} absent(s) · ${c.RETARD} en retard`;
}

function attValidate() {
    const d = attDraft;
    if (!d) return;
    const entries = {};
    d.roster.forEach(st => { entries[st.id] = { status: d.statuses[st.id] || "PRESENT", note: d.notes[st.id] || null }; });
    attDirty[d.key] = { class_id: d.class_id, date: d.date, hour: d.hour, entries };
    lsSet("sekolify_att_dirty", attDirty);
    lsDel("sekolify_att_draft");
    attDraft = null;
    setTab("attendance", true);
    history.back();                                   // retour à l'onglet Appel
    setTimeout(() => attSync(true), 200);             // envoi immédiat si le PC répond, sinon on garde en attente
}

// --- ENVOI AU PC ---
function attCommitBase(key, sess) {
    attBase[key] = {};
    Object.entries(sess.entries).forEach(([id, e]) => { attBase[key][id] = { status: e.status, note: e.note || null }; });
    const a = attData();
    if (a && sess.date === a.today) {                 // garde le cache local cohérent avec le PC
        a.sessions = (a.sessions || []).filter(x => !(x.class_id === sess.class_id && x.hour === sess.hour));
        a.sessions.push({
            class_id: sess.class_id, hour: sess.hour,
            rows: Object.entries(sess.entries).map(([id, e]) => ({ student_id: Number(id), status: e.status, note: e.note || null })),
        });
        lsSet("sekolify_data", teacherData);
    }
}

async function attSync(auto) {
    const keys = Object.keys(attDirty);
    if (!keys.length) { if (!auto) showToast("Aucun appel à envoyer."); return; }
    if (attSyncing) return;
    attSyncing = true;
    renderAttendanceHome();

    const sent = keys.map(k => attDirty[k]);
    const sessions = sent.map(s => ({
        class_id: s.class_id, date: s.date, hour: s.hour,
        entries: Object.entries(s.entries).map(([id, e]) => ({ student_id: Number(id), status: e.status, note: e.note || null })),
    }));

    try {
        const r = await api("POST", "/api/sync-presences", { sessions }, 20000);
        if (r.status === 401) { sessionExpired(); return; }
        if (r.status === 403) { showToast((r.data && r.data.error) || "Accès refusé."); return; }
        const data = r.data || {};
        if (r.status !== 200 || !Array.isArray(data.results)) throw new Error(data.error || "Erreur serveur");

        let ok = 0;
        const refused = [];
        data.results.forEach((res, i) => {
            const k = keys[i];
            if (!k) return;
            if (res.ok) { attCommitBase(k, sent[i]); ok++; }
            else refused.push(res.error || "refusé");
            if (attDirty[k] === sent[i]) delete attDirty[k];     // un appel refusé est définitivement invalide : on l'écarte
        });
        lsSet("sekolify_att_dirty", attDirty);
        if (refused.length) showToast(`${ok} appel(s) envoyé(s), ${refused.length} refusé(s) : ${refused[0]}`, "triangle-alert");
        else showToast(`${ok} appel(s) de présence envoyé(s) au PC`, "check");
    } catch (err) {
        showToast(auto ? "Appel enregistré sur le téléphone : il sera envoyé dès que le PC sera joignable."
                       : "PC injoignable : vos appels restent enregistrés sur le téléphone.");
    } finally {
        attSyncing = false;
        renderAttendanceHome();
    }
}
