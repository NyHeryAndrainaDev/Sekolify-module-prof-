# Sekolify Licences (APK, usage personnel)

App Android (Capacitor + HTML/CSS/JS) qui remplace `generate.py`.
La licence produite est identique : même JSON compact, `expires_at` au format `YYYY-MM-DD HH:MM:SS` (UTC), signature Ed25519, Base64 URL-safe.

## Obtenir l'APK
1. Crée un dépôt **privé** sur GitHub (la clé privée n'est jamais dans le dépôt, mais garde-le privé quand même).
2. Envoie tout le contenu de ce dossier à la racine du dépôt, **y compris `.github/workflows/build-apk.yml`**.
   Si le dossier `.github` n'apparaît pas à l'upload : sur GitHub > Add file > Create new file, tape
   `.github/workflows/build-apk.yml` comme nom, et colle le contenu du fichier.
3. Onglet **Actions** > « Build APK » (se lance au push, ou bouton *Run workflow*).
4. Quand c'est vert (~5-8 min), ouvre l'exécution > **Artifacts** > `sekolify-licences-apk` > télécharge, dézippe, installe `app-debug.apk`
   (autorise « installer des apps inconnues »).

## Sécurité
- `private_key.pem` est importée dans l'app une seule fois, puis chiffrée (AES-GCM, clé WebCrypto non extractible) dans le stockage privé de l'app.
- Ne mets jamais `private_key.pem` sur GitHub (le `.gitignore` l'exclut).
- Les écoles/licences sont stockées uniquement sur le téléphone : utilise Réglages > Exporter pour sauvegarder.
