/* Stockage de la clé privée : chiffrée en AES-GCM avec une clé WebCrypto NON EXTRACTIBLE,
 * conservée dans IndexedDB. Le seed n'est jamais écrit en clair sur le disque. */
(function (root) {
  'use strict';
  const DB = 'sekolify-ks', STORE = 'k';

  function open() {
    return new Promise((res, rej) => {
      const r = indexedDB.open(DB, 1);
      r.onupgradeneeded = () => r.result.createObjectStore(STORE);
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  async function tx(mode, fn) {
    const db = await open();
    return new Promise((res, rej) => {
      const t = db.transaction(STORE, mode);
      const out = fn(t.objectStore(STORE));
      t.oncomplete = () => { db.close(); res(out && out.result); };
      t.onerror = () => { db.close(); rej(t.error); };
    });
  }
  const get = (k) => tx('readonly', (s) => s.get(k));
  const put = (k, v) => tx('readwrite', (s) => s.put(v, k));

  async function aesKey() {
    let key = await get('aes');
    if (!key) {
      key = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
      await put('aes', key);
    }
    return key;
  }
  async function saveSeed(seed) {
    const key = await aesKey();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, seed);
    await put('seed', { iv, ct });
  }
  async function loadSeed() {
    const rec = await get('seed');
    if (!rec) return null;
    const key = await aesKey();
    return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: rec.iv }, key, rec.ct));
  }
  async function hasSeed() { return !!(await get('seed')); }
  async function clear() { await tx('readwrite', (s) => s.clear()); }

  root.KS = { saveSeed, loadSeed, hasSeed, clear };
})(self);
