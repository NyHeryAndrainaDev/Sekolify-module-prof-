/* Génération du reçu : dessin sur canvas (A5, 150 dpi) + export PNG / PDF (sans dépendance). */
(function (root) {
  'use strict';
  const W = 1240, H = 1748;
  const FONT = '"Roboto","Segoe UI",system-ui,-apple-system,sans-serif';
  const MONO = '"Roboto Mono","SFMono-Regular",Consolas,monospace';

  function roundRect(c, x, y, w, h, r) {
    c.beginPath();
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
  }
  function fit(c, text, weight, size, maxW, font = FONT) {
    let s = size;
    do { c.font = `${weight} ${s}px ${font}`; s -= 2; } while (c.measureText(text).width > maxW && s > 20);
  }

  async function loadImage(src) {
    if (!src) return null;
    return new Promise((res) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = src; });
  }

  /* d = { issuer, contact, footer, currency, logo(dataURL|null),
           school, no, plan, machine_id, issued (str), expiresUTC (str), expiresLocal (str), days, amount (str|null) } */
  async function render(d) {
    const cv = document.createElement('canvas');
    cv.width = W; cv.height = H;
    const c = cv.getContext('2d');
    const logo = await loadImage(d.logo);

    c.fillStyle = '#ffffff'; c.fillRect(0, 0, W, H);

    // En-tête
    const g = c.createLinearGradient(0, 0, W, 360);
    g.addColorStop(0, '#3b3fd8'); g.addColorStop(0.6, '#5b6cff'); g.addColorStop(1, '#14b8d4');
    c.fillStyle = g; c.fillRect(0, 0, W, 360);
    c.fillStyle = 'rgba(255,255,255,.07)';
    c.beginPath(); c.arc(1080, 40, 260, 0, Math.PI * 2); c.fill();
    c.beginPath(); c.arc(900, 380, 150, 0, Math.PI * 2); c.fill();

    // Logo
    c.fillStyle = '#ffffff'; roundRect(c, 80, 90, 150, 150, 36); c.fill();
    if (logo) {
      const s = Math.min(118 / logo.width, 118 / logo.height);
      c.drawImage(logo, 96 + (118 - logo.width * s) / 2, 106 + (118 - logo.height * s) / 2, logo.width * s, logo.height * s);
    } else {
      c.fillStyle = '#4f46e5'; c.font = `800 92px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText((d.issuer || 'S').trim().charAt(0).toUpperCase(), 155, 168);
    }
    c.textAlign = 'left'; c.textBaseline = 'alphabetic';
    c.fillStyle = '#fff';
    fit(c, d.issuer, 800, 64, 520); c.fillText(d.issuer, 258, 160);
    c.font = `400 28px ${FONT}`; c.fillStyle = 'rgba(255,255,255,.85)';
    c.fillText('Licence logicielle', 260, 205);

    c.textAlign = 'right'; c.fillStyle = '#fff';
    c.font = `800 80px ${FONT}`; c.fillText('REÇU', W - 80, 168);
    c.font = `500 30px ${MONO}`; c.fillStyle = 'rgba(255,255,255,.92)';
    c.fillText(d.no, W - 80, 214);
    c.textAlign = 'left';

    // Destinataire
    let y = 460;
    c.fillStyle = '#8a92ad'; c.font = `600 26px ${FONT}`;
    c.fillText('DÉLIVRÉ À', 80, y);
    c.fillStyle = '#10142b';
    fit(c, d.school, 800, 64, W - 160); c.fillText(d.school, 80, y + 78);
    c.fillStyle = '#6b7390'; c.font = `400 28px ${FONT}`;
    c.fillText(`Émis le ${d.issued}`, 80, y + 130);

    // Tableau
    y = 680;
    const rows = [
      ['Plan', d.plan, 'plan'],
      ['Machine ID', d.machine_id, 'mono'],
      ['Durée accordée', `${d.days} jour${d.days > 1 ? 's' : ''}`, ''],
      ['Valable jusqu’au', d.expiresLocal, ''],
      ['', `${d.expiresUTC} UTC`, 'sub'],
    ];
    const rh = 92, th = rows.length * rh - 10 + 20;
    c.fillStyle = '#f4f5fb'; roundRect(c, 60, y - 10, W - 120, th, 36); c.fill();
    let ry = y + 30;
    rows.forEach((r, i) => {
      if (r[2] !== 'sub') {
        c.textAlign = 'left'; c.fillStyle = '#7a829e'; c.font = `500 28px ${FONT}`;
        c.fillText(r[0], 100, ry + 28);
      }
      c.textAlign = 'right';
      if (r[2] === 'plan') {
        const premium = r[1] === 'PREMIUM';
        c.font = `800 26px ${FONT}`;
        const tw = c.measureText(r[1]).width + 56;
        const gx = c.createLinearGradient(W - 100 - tw, 0, W - 100, 0);
        if (premium) { gx.addColorStop(0, '#f59e0b'); gx.addColorStop(1, '#fbbf24'); } else { gx.addColorStop(0, '#64748b'); gx.addColorStop(1, '#94a3b8'); }
        c.fillStyle = gx; roundRect(c, W - 100 - tw, ry - 2, tw, 52, 26); c.fill();
        c.fillStyle = premium ? '#3b2a00' : '#fff'; c.fillText(r[1], W - 100 - 28, ry + 35);
      } else if (r[2] === 'mono') {
        c.fillStyle = '#10142b'; fit(c, r[1], 600, 34, 620, MONO); c.fillText(r[1], W - 100, ry + 30);
      } else if (r[2] === 'sub') {
        c.fillStyle = '#8a92ad'; c.font = `400 25px ${MONO}`; c.fillText(r[1], W - 100, ry - 6);
      } else {
        c.fillStyle = '#10142b'; fit(c, r[1], 600, 32, 640); c.fillText(r[1], W - 100, ry + 30);
      }
      if (i < 3) { c.fillStyle = '#e3e6f2'; c.fillRect(100, ry + 64, W - 200, 2); }
      ry += rh;
    });
    c.textAlign = 'left';

    // Montant
    y = 680 + th + 50;
    if (d.amount) {
      const ag = c.createLinearGradient(60, y, W - 60, y + 170);
      ag.addColorStop(0, '#12183a'); ag.addColorStop(1, '#232a66');
      c.fillStyle = ag; roundRect(c, 60, y, W - 120, 170, 36); c.fill();
      c.fillStyle = 'rgba(255,255,255,.65)'; c.font = `600 26px ${FONT}`;
      c.fillText('MONTANT', 110, y + 62);
      c.fillStyle = '#fff'; c.textAlign = 'right';
      fit(c, d.amount, 800, 74, 760); c.fillText(d.amount, W - 110, y + 118);
      c.textAlign = 'left';
      y += 170 + 50;
    }

    // Signature
    const sy = Math.max(y + 110, 1380);
    c.strokeStyle = '#c8cde0'; c.lineWidth = 2; c.setLineDash([8, 8]);
    c.beginPath(); c.moveTo(80, sy); c.lineTo(520, sy); c.stroke();
    c.setLineDash([]);
    c.fillStyle = '#8a92ad'; c.font = `400 24px ${FONT}`;
    c.fillText('Cachet & signature', 80, sy + 40);

    // Pied
    const fg = c.createLinearGradient(0, 0, W, 0);
    fg.addColorStop(0, '#3b3fd8'); fg.addColorStop(1, '#14b8d4');
    c.fillStyle = fg; c.fillRect(0, H - 18, W, 18);
    c.textAlign = 'center';
    c.fillStyle = '#4a5273'; c.font = `500 28px ${FONT}`;
    if (d.footer) c.fillText(d.footer, W / 2, H - 112);
    if (d.contact) { c.fillStyle = '#8a92ad'; c.font = `400 25px ${FONT}`; c.fillText(d.contact, W / 2, H - 66); }
    c.textAlign = 'left';
    return cv;
  }

  /* PDF A5 avec l'image JPEG pleine page. */
  function pdfFromJpeg(jpeg, wPx, hPx) {
    const enc = new TextEncoder();
    const parts = []; let len = 0; const off = [];
    const push = (b) => { const u = typeof b === 'string' ? enc.encode(b) : b; parts.push(u); len += u.length; };
    const PW = 419.53, PH = 595.28;
    push('%PDF-1.4\n');
    const obj = (n, head, stream) => {
      off[n] = len;
      push(`${n} 0 obj\n<<${head}${stream ? ` /Length ${stream.length}` : ''}>>\n`);
      if (stream) { push('stream\n'); push(stream); push('\nendstream\n'); }
      push('endobj\n');
    };
    obj(1, '/Type /Catalog /Pages 2 0 R');
    obj(2, '/Type /Pages /Kids [3 0 R] /Count 1');
    obj(3, `/Type /Page /Parent 2 0 R /MediaBox [0 0 ${PW} ${PH}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R`);
    obj(4, `/Type /XObject /Subtype /Image /Width ${wPx} /Height ${hPx} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode`, jpeg);
    obj(5, '', enc.encode(`q ${PW} 0 0 ${PH} 0 0 cm /Im0 Do Q`));
    const xref = len;
    push('xref\n0 6\n0000000000 65535 f \n');
    for (let i = 1; i <= 5; i++) push(String(off[i]).padStart(10, '0') + ' 00000 n \n');
    push(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
    const out = new Uint8Array(len); let o = 0;
    for (const p of parts) { out.set(p, o); o += p.length; }
    return out;
  }

  async function toJpegBytes(cv, q = 0.92) {
    const blob = await new Promise((r) => cv.toBlob(r, 'image/jpeg', q));
    return new Uint8Array(await blob.arrayBuffer());
  }
  async function toPdf(cv) { return pdfFromJpeg(await toJpegBytes(cv), cv.width, cv.height); }
  async function toPng(cv) {
    const blob = await new Promise((r) => cv.toBlob(r, 'image/png'));
    return new Uint8Array(await blob.arrayBuffer());
  }

  root.Receipt = { render, toPdf, toPng, pdfFromJpeg, toJpegBytes };
})(self);
