(() => {
'use strict';

/* ================= Utilitaires ================= */
const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = (n, l = 2) => String(n).padStart(l, '0');
const ICON = {
  plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
  gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
  search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
  receipt: '<svg viewBox="0 0 24 24"><path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/></svg>',
  copy: '<svg viewBox="0 0 24 24"><rect x="9" y="9" width="12" height="12" rx="3"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg>',
  share: '<svg viewBox="0 0 24 24"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/></svg>',
  key: '<svg viewBox="0 0 24 24"><circle cx="8" cy="15" r="4"/><path d="m11 12 9-9m-3 3 3 3m-6-1 2 2"/></svg>',
  trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>',
  refresh: '<svg viewBox="0 0 24 24"><path d="M20 11a8 8 0 0 0-14-4L4 9M4 4v5h5M4 13a8 8 0 0 0 14 4l2-2M20 20v-5h-5"/></svg>',
  check: '<svg viewBox="0 0 24 24"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>',
  upload: '<svg viewBox="0 0 24 24"><path d="M12 16V4m0 0-4 4m4-4 4 4M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/></svg>',
  edit: '<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/></svg>',
  clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  inbox: '<svg viewBox="0 0 24 24"><path d="M3 13l3-8h12l3 8v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM3 13h5a4 4 0 0 0 8 0h5"/></svg>',
};
const PLANS = { BASIC: { label: 'BASIC', desc: 'Découverte' }, PREMIUM: { label: 'PREMIUM', desc: 'Complet + Prof Mobile' } };

const Store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { toast('Stockage plein ou indisponible'); return false; } },
  del(k) { try { localStorage.removeItem(k); } catch (e) { /* noop */ } },
};

/* ================= État ================= */
const DEFAULTS = { issuer: 'Sekolify', currency: 'Ar', footer: 'Merci pour votre confiance.', contact: '', theme: 'dark', seq: 0 };
let settings = { ...DEFAULTS, ...Store.get('sk_settings', {}) };
let licences = Store.get('sk_licences', []);
let logo = Store.get('sk_logo', null);
let pubB64 = Store.get('sk_pub', '');
let filter = 'all', query = '';
const saveAll = () => { Store.set('sk_licences', licences); Store.set('sk_settings', settings); };

/* ================= Temps ================= */
const fmtUTC = (d) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
const parseUTC = (s) => { const m = /^(\d{4})-(\d{2})-(\d{2})(?: (\d{2}):(\d{2}):(\d{2}))?$/.exec(s); return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0))); };
const nowSec = () => new Date(Math.floor(Date.now() / 1000) * 1000);
function diffParts(a, b) {
  let y = b.getUTCFullYear() - a.getUTCFullYear(), mo = b.getUTCMonth() - a.getUTCMonth(), d = b.getUTCDate() - a.getUTCDate();
  let h = b.getUTCHours() - a.getUTCHours(), mi = b.getUTCMinutes() - a.getUTCMinutes(), s = b.getUTCSeconds() - a.getUTCSeconds();
  if (s < 0) { s += 60; mi--; } if (mi < 0) { mi += 60; h--; } if (h < 0) { h += 24; d--; }
  if (d < 0) { d += new Date(Date.UTC(b.getUTCFullYear(), b.getUTCMonth(), 0)).getUTCDate(); mo--; }
  if (mo < 0) { mo += 12; y--; }
  return { y, mo, d, h, mi, s };
}
const cur = (l) => l.entries[l.entries.length - 1];
const endOf = (l) => parseUTC(cur(l).expires_at);
function status(l) {
  const ms = endOf(l) - Date.now();
  if (ms <= 0) return 'off';
  const days = ms / 864e5;
  return days < 7 ? 'danger' : days < 30 ? 'warn' : 'ok';
}
const localFmt = (d, withSec = true) => d.toLocaleString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', ...(withSec ? { second: '2-digit' } : {}) });
const shortDate = (d) => d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
function cdCells(l, big) {
  const end = endOf(l), now = nowSec();
  if (end <= now) return null;
  const p = diffParts(now, end);
  const cells = [[p.y, 'ans'], [p.mo, 'mois'], [p.d, 'jours'], [pad(p.h), 'h'], [pad(p.mi), 'min'], [pad(p.s), 's']];
  return cells.map((c, i) => `<div><b data-k="${i}">${c[0]}</b><small>${c[1]}</small></div>`).join('');
}
function expiredText(l) {
  const p = diffParts(endOf(l), nowSec());
  const parts = [];
  if (p.y) parts.push(`${p.y} an${p.y > 1 ? 's' : ''}`);
  if (p.mo) parts.push(`${p.mo} mois`);
  if (p.d || !parts.length) parts.push(`${p.d} j`);
  return `Expirée depuis ${parts.join(' ')}`;
}

/* ================= UI de base ================= */
let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2200); }
function applyTheme() { document.documentElement.dataset.theme = settings.theme; }

const layer = $('#layer');
const stack = [];
function openOverlay(html, { center = false, onMount, onClose } = {}) {
  const ov = document.createElement('div');
  ov.className = 'overlay' + (center ? ' center' : '');
  ov.innerHTML = center ? `<div class="modal">${html}</div>` : `<div class="sheet"><div class="grab"></div>${html}</div>`;
  layer.appendChild(ov);
  const api = { el: ov, close() { if (!ov.isConnected) return; ov.remove(); const i = stack.indexOf(api); if (i >= 0) stack.splice(i, 1); onClose && onClose(); } };
  ov.addEventListener('click', (e) => { if (e.target === ov) api.close(); });
  stack.push(api);
  onMount && onMount(ov, api);
  return api;
}
function ask({ title, text = '', ok = 'OK', cancel = 'Annuler', danger = false, input = null }) {
  return new Promise((res) => {
    let done = false;
    const finish = (v) => { if (done) return; done = true; res(v); };
    const m = openOverlay(`<h3>${esc(title)}</h3>${text ? `<p>${esc(text)}</p>` : ''}${input !== null ? `<input class="input" id="ask-in" value="${esc(input)}" style="margin-bottom:14px">` : ''}
      <div class="row"><button class="btn" data-a="no">${esc(cancel)}</button><button class="btn ${danger ? 'danger' : 'primary'}" data-a="yes">${esc(ok)}</button></div>`,
      { center: true, onClose: () => finish(null), onMount: (ov) => {
        ov.addEventListener('click', (e) => { const a = e.target.closest('[data-a]')?.dataset.a; if (!a) return; if (a === 'yes') finish(input !== null ? $('#ask-in', ov).value : true); m.close(); });
        input !== null && setTimeout(() => $('#ask-in', ov).focus(), 80);
      } });
  });
}

/* ================= Fichiers / partage ================= */
const Cap = () => window.Capacitor;
const native = () => !!(Cap() && Cap().isNativePlatform && Cap().isNativePlatform());
function b64(bytes) { let s = ''; const ch = 0x8000; for (let i = 0; i < bytes.length; i += ch) s += String.fromCharCode.apply(null, bytes.subarray(i, i + ch)); return btoa(s); }
async function shareFile(name, bytes, mime, title) {
  if (native()) {
    try {
      const P = Cap().Plugins;
      const w = await P.Filesystem.writeFile({ path: name, data: b64(bytes), directory: 'CACHE' });
      await P.Share.share({ title, files: [w.uri], dialogTitle: title });
      return;
    } catch (e) { if (/cancel/i.test(String(e && e.message))) return; toast('Partage impossible : ' + (e.message || e)); return; }
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([bytes], { type: mime }));
  a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
async function shareText(text, title) {
  if (native()) { try { await Cap().Plugins.Share.share({ title, text, dialogTitle: title }); } catch (e) { /* annulé */ } return; }
  if (navigator.share) { try { await navigator.share({ title, text }); } catch (e) { /* annulé */ } return; }
  copy(text);
}
async function copy(text) {
  try { await navigator.clipboard.writeText(text); } catch (e) {
    const t = document.createElement('textarea'); t.value = text; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); } catch (_) { /* noop */ } t.remove();
  }
  toast('Copié');
}
const readText = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsText(f); });
const readDataURL = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); });
const hex = (u, n = u.length) => Array.from(u.slice(0, n), (b) => pad(b.toString(16))).join('');
const b64u = (u) => b64(u).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

/* ================= Écran 1 : clé ================= */
function showSetup(replace = false) {
  $('#screen-dash').hidden = true; $('#screen-setup').hidden = false;
  $('#drop-ic').innerHTML = ICON.key;
  $('#setup-ok-ic').innerHTML = ICON.check;
  $('#setup-continue').hidden = true; $('#setup-result').hidden = true; $('#setup-error').hidden = true;
  $('#drop').classList.remove('ok');
  $('#drop-title').textContent = 'Importer private_key.pem';
  $('#drop-sub').textContent = 'Touche pour choisir le fichier de ta clé privée Ed25519';
  setupSeed = null; setupReplace = replace;
}
let setupSeed = null, setupReplace = false;
$('#pem-input').addEventListener('change', async (e) => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  const err = $('#setup-error'); err.hidden = true;
  $('#setup-result').hidden = true; $('#setup-continue').hidden = true; $('#drop').classList.remove('ok');
  try {
    const seed = Ed25519.parsePem(await readText(f));
    const pub = await Ed25519.getPublicKey(seed);
    setupSeed = seed; setupPub = pub;
    $('#setup-fp').textContent = hex(pub, 8).replace(/(.{4})/g, '$1 ').trim().toUpperCase() + ' …';
    $('#setup-result').hidden = false; $('#setup-continue').hidden = false;
    $('#drop').classList.add('ok'); $('#drop-title').textContent = f.name; $('#drop-sub').textContent = 'Touche pour choisir un autre fichier';
  } catch (ex) { err.textContent = ex.message || String(ex); err.hidden = false; }
});
let setupPub = null;
$('#setup-continue').addEventListener('click', async () => {
  if (!setupSeed) return;
  try {
    await KS.saveSeed(setupSeed);
    pubB64 = b64(setupPub); Store.set('sk_pub', pubB64);
    setupSeed = null;
    toast(setupReplace ? 'Clé remplacée' : 'Clé enregistrée');
    showDash();
  } catch (ex) { const err = $('#setup-error'); err.textContent = 'Enregistrement impossible : ' + (ex.message || ex); err.hidden = false; }
});

/* ================= Écran 2 : dashboard ================= */
function showDash() {
  $('#screen-setup').hidden = true; $('#screen-dash').hidden = false;
  $('#btn-search').innerHTML = ICON.search; $('#btn-settings').innerHTML = ICON.gear; $('#fab').innerHTML = ICON.plus;
  renderAll();
}
const sortLic = (a, b) => {
  const ea = endOf(a), eb = endOf(b), n = Date.now(), aa = ea > n, ab = eb > n;
  if (aa !== ab) return aa ? -1 : 1;
  return aa ? ea - eb : eb - ea;
};
function counts() {
  const c = { all: licences.length, active: 0, soon: 0, expired: 0 };
  licences.forEach((l) => { const s = status(l); if (s === 'off') c.expired++; else { c.active++; if (s !== 'ok') c.soon++; } });
  return c;
}
function renderAll() { renderChips(); renderList(); }
function renderChips() {
  const c = counts();
  const defs = [['all', 'Toutes', c.all], ['active', 'Actives', c.active], ['soon', 'Bientôt', c.soon], ['expired', 'Expirées', c.expired]];
  $('#chips').innerHTML = defs.map(([k, t, n]) => `<button class="chip ${filter === k ? 'on' : ''}" data-f="${k}">${t}<b>${n}</b></button>`).join('');
  $('#summary').textContent = c.all ? `${c.all} école${c.all > 1 ? 's' : ''} · ${c.active} active${c.active > 1 ? 's' : ''}` : 'Aucune école pour le moment';
}
$('#chips').addEventListener('click', (e) => { const b = e.target.closest('[data-f]'); if (!b) return; filter = b.dataset.f; renderAll(); });
$('#btn-search').addEventListener('click', () => { const bar = $('#searchbar'); bar.hidden = !bar.hidden; if (!bar.hidden) $('#search').focus(); else { query = ''; $('#search').value = ''; renderList(); } });
$('#search').addEventListener('input', (e) => { query = e.target.value.trim().toLowerCase(); renderList(); });

function visible() {
  return licences.filter((l) => {
    const s = status(l);
    if (filter === 'active' && s === 'off') return false;
    if (filter === 'soon' && (s === 'off' || s === 'ok')) return false;
    if (filter === 'expired' && s !== 'off') return false;
    if (query && !(l.school.toLowerCase().includes(query) || cur(l).machine_id.toLowerCase().includes(query))) return false;
    return true;
  }).sort(sortLic);
}
let rendered = {};
function renderList() {
  const items = visible();
  const box = $('#list');
  if (!items.length) {
    const none = !licences.length;
    box.innerHTML = `<div class="empty"><div class="ill">${ICON.inbox}</div><h3>${none ? 'Aucune licence' : 'Aucun résultat'}</h3><div>${none ? 'Touche + pour créer la première licence.' : 'Essaie un autre filtre ou une autre recherche.'}</div></div>`;
    rendered = {}; return;
  }
  rendered = {};
  box.innerHTML = items.map((l, i) => {
    const e = cur(l), s = status(l); rendered[l.id] = s;
    const cd = cdCells(l);
    return `<article class="card st-${s}" data-id="${l.id}" style="animation-delay:${Math.min(i, 8) * 40}ms">
      <div class="card-head"><div><div class="school">${esc(l.school)}</div><div class="meta">${esc(e.machine_id)}</div></div><span class="plan ${e.plan === 'PREMIUM' ? 'premium' : ''}">${e.plan}</span></div>
      ${cd ? `<div class="cd">${cd}</div>` : `<div class="cd-expired">${ICON.clock}<span class="exp-t">${esc(expiredText(l))}</span></div>`}
      <div class="card-foot"><button class="btn sm" data-act="receipt">${ICON.receipt} Reçu</button><button class="btn sm" data-act="copy">${ICON.copy} Code</button>${s === 'off' ? `<button class="btn sm primary" data-act="renew">${ICON.refresh} Renouveler</button>` : ''}</div>
    </article>`;
  }).join('');
}
$('#list').addEventListener('click', (e) => {
  const card = e.target.closest('.card'); if (!card) return;
  const l = licences.find((x) => x.id === card.dataset.id); if (!l) return;
  const act = e.target.closest('[data-act]')?.dataset.act;
  if (act === 'receipt') return openReceipt(l, cur(l));
  if (act === 'copy') return copy(cur(l).code);
  if (act === 'renew') return openForm(l);
  openDetail(l);
});

/* tick 1 s : met à jour les compteurs sans re-render */
setInterval(() => {
  if ($('#screen-dash').hidden) return;
  let rerender = false;
  document.querySelectorAll('.card').forEach((card) => {
    const l = licences.find((x) => x.id === card.dataset.id); if (!l) return;
    if (status(l) !== rendered[l.id]) { rerender = true; return; }
    const exp = card.querySelector('.exp-t');
    if (exp) { exp.textContent = expiredText(l); return; }
    fillCd(card, l);
  });
  if (rerender) { renderAll(); const d = $('#detail-cd'); if (d) d.closest('.overlay').__refresh && d.closest('.overlay').__refresh(); }
  const dc = $('#detail-cd'); if (dc && dc.__lic) fillCd(dc, dc.__lic);
}, 1000);
function fillCd(root, l) {
  const end = endOf(l), now = nowSec(); if (end <= now) return;
  const p = diffParts(now, end), v = [p.y, p.mo, p.d, pad(p.h), pad(p.mi), pad(p.s)];
  root.querySelectorAll('[data-k]').forEach((b) => { const t = String(v[+b.dataset.k]); if (b.textContent !== t) b.textContent = t; });
}

/* ================= Nouvelle licence / renouvellement ================= */
function pyJsonStr(s) { return JSON.stringify(s).replace(/[\u007f-￿]/g, (c) => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0')); }
async function issue({ machine_id, plan, days }) {
  const seed = await KS.loadSeed();
  if (!seed) throw new Error('Clé privée introuvable. Réimporte-la dans les réglages.');
  const expires_at = fmtUTC(new Date(Date.now() + days * 864e5));
  // Même sérialisation que json.dumps(payload, separators=(',', ':'))
  const json = `{"machine_id":${pyJsonStr(machine_id)},"plan":${pyJsonStr(plan)},"expires_at":${pyJsonStr(expires_at)}}`;
  const bytes = new TextEncoder().encode(json);
  const sig = await Ed25519.sign(bytes, seed);
  return { expires_at, code: `${b64u(bytes)}.${b64u(sig)}` };
}
function nextNo() { settings.seq = (settings.seq || 0) + 1; return `SKL-${new Date().getFullYear()}-${pad(settings.seq, 4)}`; }

function openForm(renewing = null) {
  const last = renewing ? cur(renewing) : null;
  let plan = last ? last.plan : 'PREMIUM', days = 365;
  const m = openOverlay(`
    <h2>${renewing ? 'Renouveler' : 'Nouvelle licence'}</h2>
    <p class="lead">${renewing ? 'Une nouvelle licence sera émise pour cette école.' : 'Renseigne l’école et le Machine ID affiché par Sekolify.'}</p>
    <div id="form-body">
      <div class="field"><label>École</label><input class="input" id="f-school" placeholder="Ex : Lycée Rainilaiarivony" value="${esc(renewing ? renewing.school : '')}" autocomplete="off"></div>
      <div class="field"><label>Machine ID</label><input class="input mono" id="f-mid" placeholder="A1B2-C3D4-E5F6-7890" value="${esc(last ? last.machine_id : '')}" autocapitalize="characters" autocomplete="off" spellcheck="false"><div class="hint" id="f-mid-hint" hidden>Format inhabituel (attendu : XXXX-XXXX-XXXX-XXXX). Tu peux continuer si c’est voulu.</div></div>
      <div class="field"><label>Plan</label><div class="plans">
        ${Object.entries(PLANS).map(([k, v]) => `<button type="button" class="plan-opt ${k === 'PREMIUM' ? 'prem' : ''} ${plan === k ? 'on' : ''}" data-plan="${k}"><b>${v.label}</b><small>${v.desc}</small></button>`).join('')}</div></div>
      <div class="field"><label>Durée de validité</label>
        <div class="days">${[30, 90, 180, 365, 730].map((d) => `<button type="button" class="chip ${d === days ? 'on' : ''}" data-days="${d}">${d} j</button>`).join('')}</div>
        <input class="input" id="f-days" type="number" inputmode="numeric" min="1" max="3650" value="${days}" placeholder="Nombre de jours"></div>
      <div class="field"><label>Montant payé (optionnel, pour le reçu)</label><div class="row"><input class="input" id="f-amt" type="number" inputmode="decimal" min="0" placeholder="0" style="flex:2"><input class="input" id="f-cur" value="${esc(settings.currency)}" style="flex:1" placeholder="Ar"></div></div>
      <div class="preview">${ICON.clock}<span>Expire le <b id="f-exp"></b><br><small id="f-exp-utc"></small></span></div>
      <button class="btn primary big" id="f-go" style="width:100%">Générer la licence</button>
    </div>`, { onMount: (ov) => {
    const q = (s) => $(s, ov);
    const upd = () => {
      const n = parseInt(q('#f-days').value, 10);
      const d = new Date(Date.now() + (n > 0 ? n : 0) * 864e5);
      q('#f-exp').textContent = n > 0 ? localFmt(d, false) : '—'; q('#f-exp-utc').textContent = n > 0 ? fmtUTC(d) + ' UTC' : '';
      ov.querySelectorAll('[data-days]').forEach((b) => b.classList.toggle('on', +b.dataset.days === n));
    };
    upd();
    ov.addEventListener('click', (e) => {
      const p = e.target.closest('[data-plan]'); if (p) { plan = p.dataset.plan; ov.querySelectorAll('[data-plan]').forEach((b) => b.classList.toggle('on', b === p)); }
      const d = e.target.closest('[data-days]'); if (d) { q('#f-days').value = d.dataset.days; upd(); }
    });
    q('#f-days').addEventListener('input', upd);
    q('#f-mid').addEventListener('input', () => { q('#f-mid-hint').hidden = !q('#f-mid').value.trim() || /^[0-9A-F]{4}(-[0-9A-F]{4}){3}$/i.test(q('#f-mid').value.trim()); });
    q('#f-go').addEventListener('click', async () => {
      const school = q('#f-school').value.trim(), mid = q('#f-mid').value.trim(), n = parseInt(q('#f-days').value, 10);
      if (!school) return toast('Nom de l’école requis');
      if (!mid) return toast('Machine ID requis');
      if (!(n >= 1 && n <= 3650)) return toast('Durée : 1 à 3650 jours');
      if (!renewing) {
        const dup = licences.find((l) => cur(l).machine_id.toLowerCase() === mid.toLowerCase());
        if (dup) { const ok = await ask({ title: 'Machine déjà enregistrée', text: `Ce Machine ID existe déjà pour « ${dup.school} ». Créer quand même une licence séparée ?`, ok: 'Créer' }); if (!ok) return; }
      }
      const btn = q('#f-go'); btn.disabled = true; btn.textContent = 'Signature…';
      try {
        const r = await issue({ machine_id: mid, plan, days: n });
        const amt = parseFloat(q('#f-amt').value);
        settings.currency = q('#f-cur').value.trim() || settings.currency;
        const entry = { no: nextNo(), issued_at: new Date().toISOString(), machine_id: mid, plan, days: n, expires_at: r.expires_at, amount: amt > 0 ? amt : null, currency: settings.currency, code: r.code };
        let lic;
        if (renewing) { renewing.school = school; renewing.entries.push(entry); lic = renewing; }
        else { lic = { id: 'l' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), school, entries: [entry] }; licences.push(lic); }
        saveAll(); renderAll();
        showResult(m, lic, entry);
      } catch (ex) { btn.disabled = false; btn.textContent = 'Générer la licence'; toast(ex.message || String(ex)); }
    });
  } });
}
function showResult(m, lic, entry) {
  const sheet = m.el.querySelector('.sheet');
  sheet.innerHTML = `<div class="grab"></div>
    <div class="success"><div class="tick">${ICON.check}</div><h2>Licence générée</h2><p class="lead">${esc(lic.school)} · ${entry.plan}<br>Expire le ${esc(localFmt(parseUTC(entry.expires_at), false))}</p></div>
    <div class="lbl">Code de licence à envoyer au client</div>
    <div class="code-box selectable">${esc(entry.code)}</div>
    <div class="actions">
      <button class="btn primary" data-r="copy">${ICON.copy} Copier</button>
      <button class="btn" data-r="share">${ICON.share} Partager</button>
      <button class="btn" data-r="receipt">${ICON.receipt} Générer le reçu</button>
      <button class="btn" data-r="close">Terminer</button>
    </div>`;
  sheet.addEventListener('click', (e) => {
    const a = e.target.closest('[data-r]')?.dataset.r; if (!a) return;
    if (a === 'copy') copy(entry.code);
    if (a === 'share') shareText(entry.code, `Licence Sekolify — ${lic.school}`);
    if (a === 'receipt') { m.close(); openReceipt(lic, entry); }
    if (a === 'close') m.close();
  });
}

/* ================= Détail ================= */
function openDetail(l) {
  const render = (m) => {
    const e = cur(l), s = status(l), end = endOf(l);
    const sheet = m.el.querySelector('.sheet');
    const cd = cdCells(l);
    sheet.innerHTML = `<div class="grab"></div>
      <div class="card-head"><div><h2 style="margin-bottom:2px">${esc(l.school)}</h2><div class="meta">${esc(e.machine_id)}</div></div><span class="plan ${e.plan === 'PREMIUM' ? 'premium' : ''}">${e.plan}</span></div>
      <div style="margin-top:16px">
      ${cd ? `<div class="big-cd" id="detail-cd" style="--st:var(--${s})">${cd}</div>` : `<div class="cd-expired" style="margin-bottom:14px">${ICON.clock}<span>${esc(expiredText(l))}</span></div>`}</div>
      <div class="kv"><span>Expire (heure locale)</span><span>${esc(localFmt(end))}</span></div>
      <div class="kv"><span>Expire (UTC)</span><span class="selectable" style="font-family:var(--mono);font-size:13px">${esc(e.expires_at)}</span></div>
      <div class="kv"><span>Émise le</span><span>${esc(localFmt(new Date(e.issued_at), false))}</span></div>
      <div class="kv"><span>Durée / Reçu n°</span><span>${e.days} j · ${esc(e.no)}</span></div>
      <div class="lbl" style="margin-top:16px">Code de licence</div>
      <div class="code-box selectable">${esc(e.code)}</div>
      <div class="actions">
        <button class="btn" data-d="copy">${ICON.copy} Copier</button><button class="btn" data-d="share">${ICON.share} Partager</button>
        <button class="btn" data-d="receipt">${ICON.receipt} Reçu</button><button class="btn primary" data-d="renew">${ICON.refresh} Renouveler</button>
        <button class="btn" data-d="rename">${ICON.edit} Renommer</button><button class="btn danger" data-d="del">${ICON.trash} Supprimer</button>
      </div>
      ${l.entries.length > 1 ? `<div class="sec">Historique (${l.entries.length - 1})</div>${l.entries.slice(0, -1).reverse().map((h) => `<div class="hist"><div><b>${esc(h.no)}</b> · ${h.plan}<small>${esc(shortDate(new Date(h.issued_at)))} → ${esc(shortDate(parseUTC(h.expires_at)))}</small></div><button class="btn sm" data-h="${esc(h.no)}">${ICON.receipt}</button></div>`).join('')}` : ''}`;
    const dc = $('#detail-cd', sheet); if (dc) dc.__lic = l;
  };
  const m = openOverlay('', { onMount: (ov, api) => {
    render(api);
    ov.__refresh = () => render(api);
    ov.addEventListener('click', async (e) => {
      const h = e.target.closest('[data-h]'); if (h) { const en = l.entries.find((x) => x.no === h.dataset.h); return openReceipt(l, en); }
      const a = e.target.closest('[data-d]')?.dataset.d; if (!a) return;
      if (a === 'copy') copy(cur(l).code);
      if (a === 'share') shareText(cur(l).code, `Licence Sekolify — ${l.school}`);
      if (a === 'receipt') openReceipt(l, cur(l));
      if (a === 'renew') { api.close(); openForm(l); }
      if (a === 'rename') { const v = await ask({ title: 'Renommer l’école', input: l.school, ok: 'Enregistrer' }); if (v && v.trim()) { l.school = v.trim(); saveAll(); renderAll(); render(api); } }
      if (a === 'del') { const ok = await ask({ title: 'Supprimer cette école ?', text: 'La licence et son historique seront effacés de l’app. Le client garde son code actuel.', ok: 'Supprimer', danger: true }); if (ok) { licences = licences.filter((x) => x !== l); saveAll(); renderAll(); api.close(); toast('Supprimée'); } }
    });
  } });
}

/* ================= Reçu ================= */
async function buildReceipt(l, entry) {
  const money = entry.amount ? `${new Intl.NumberFormat('fr-FR').format(entry.amount)} ${entry.currency || settings.currency}` : null;
  const end = parseUTC(entry.expires_at);
  return Receipt.render({
    issuer: settings.issuer || 'Sekolify', contact: settings.contact, footer: settings.footer, logo,
    school: l.school, no: entry.no, plan: entry.plan, machine_id: entry.machine_id, days: entry.days, amount: money,
    issued: localFmt(new Date(entry.issued_at), false),
    expiresLocal: localFmt(end, false), expiresUTC: entry.expires_at,
  });
}
async function openReceipt(l, entry) {
  const m = openOverlay(`<h2>Reçu ${esc(entry.no)}</h2><p class="lead">${esc(l.school)}</p><div id="rc-box" style="min-height:240px;display:grid;place-items:center;color:var(--muted)">Génération…</div>
    <div class="actions"><button class="btn primary" data-r="pdf" disabled>${ICON.share} PDF</button><button class="btn" data-r="png" disabled>${ICON.share} Image</button><button class="btn full" data-r="close">Fermer</button></div>`, {
    onMount: async (ov, api) => {
      let cv;
      try { cv = await buildReceipt(l, entry); } catch (e) { $('#rc-box', ov).textContent = 'Erreur : ' + e.message; return; }
      $('#rc-box', ov).outerHTML = `<img class="receipt-img" alt="Reçu" src="${cv.toDataURL('image/jpeg', 0.85)}">`;
      ov.querySelectorAll('[disabled]').forEach((b) => b.removeAttribute('disabled'));
      const base = `Recu-${entry.no}-${l.school.replace(/[^\w]+/g, '_').slice(0, 24)}`;
      ov.addEventListener('click', async (e) => {
        const a = e.target.closest('[data-r]')?.dataset.r; if (!a) return;
        if (a === 'close') api.close();
        if (a === 'pdf') shareFile(base + '.pdf', await Receipt.toPdf(cv), 'application/pdf', `Reçu ${entry.no}`);
        if (a === 'png') shareFile(base + '.png', await Receipt.toPng(cv), 'image/png', `Reçu ${entry.no}`);
      });
    } });
}

/* ================= Réglages ================= */
function openSettings() {
  const m = openOverlay('', { onMount: (ov, api) => {
    const draw = () => {
      ov.querySelector('.sheet').innerHTML = `<div class="grab"></div><h2>Réglages</h2><p class="lead">Sekolify Licences · usage personnel</p>
      <div class="sec" style="margin-top:6px">Clé de signature</div>
      <div class="kv"><span>Clé publique (Base64)</span><span class="selectable" style="font-family:var(--mono);font-size:11.5px;max-width:60%">${esc(pubB64 || '—')}</span></div>
      <div class="actions"><button class="btn" data-s="copypub">${ICON.copy} Copier la clé publique</button><button class="btn" data-s="newkey">${ICON.key} Remplacer la clé</button></div>
      <div class="sec">Reçu</div>
      <div class="field"><label>Nom affiché</label><input class="input" id="s-issuer" value="${esc(settings.issuer)}"></div>
      <div class="row"><div class="field"><label>Devise</label><input class="input" id="s-cur" value="${esc(settings.currency)}"></div><div class="field" style="flex:2"><label>Contact (optionnel)</label><input class="input" id="s-contact" value="${esc(settings.contact)}" placeholder="Tél · e-mail"></div></div>
      <div class="field"><label>Pied de page</label><input class="input" id="s-footer" value="${esc(settings.footer)}"></div>
      <div class="field"><label>Logo</label><div class="row" style="align-items:center">${logo ? `<img class="logo-prev" src="${logo}" alt="" style="flex:none;width:64px">` : `<div class="logo-prev" style="display:grid;place-items:center;flex:none;width:64px;color:var(--muted)">S</div>`}
        <label class="btn sm" style="cursor:pointer">${ICON.upload} Importer<input type="file" id="s-logo" accept="image/*" hidden></label>${logo ? `<button class="btn sm danger" data-s="rmlogo">Retirer</button>` : ''}</div></div>
      <div class="sec">Apparence</div>
      <div class="switch"><span>Thème ${settings.theme === 'dark' ? 'sombre' : 'clair'}</span><button class="btn sm" data-s="theme">Basculer</button></div>
      <div class="sec">Données</div>
      <div class="actions"><button class="btn" data-s="export">${ICON.upload} Exporter</button><label class="btn" style="cursor:pointer">${ICON.inbox} Importer<input type="file" id="s-import" accept="*/*" hidden></label>
      <button class="btn danger full" data-s="wipe">${ICON.trash} Tout effacer (clé comprise)</button></div>
      <p class="fine" style="text-align:center;margin-top:16px">La sauvegarde contient les écoles et licences, pas la clé privée.</p>
      <button class="btn primary big" data-s="done" style="width:100%;margin-top:6px">Enregistrer</button>`;
    };
    draw();
    const read = () => {
      const g = (id) => $(id, ov); if (!g('#s-issuer')) return;
      settings.issuer = g('#s-issuer').value.trim() || 'Sekolify'; settings.currency = g('#s-cur').value.trim() || 'Ar';
      settings.contact = g('#s-contact').value.trim(); settings.footer = g('#s-footer').value.trim();
    };
    ov.addEventListener('click', async (e) => {
      const a = e.target.closest('[data-s]')?.dataset.s; if (!a) return;
      if (a === 'done') { read(); saveAll(); api.close(); toast('Réglages enregistrés'); }
      if (a === 'copypub') copy(pubB64);
      if (a === 'newkey') { read(); saveAll(); api.close(); showSetup(true); }
      if (a === 'theme') { read(); settings.theme = settings.theme === 'dark' ? 'light' : 'dark'; applyTheme(); saveAll(); draw(); }
      if (a === 'rmlogo') { read(); logo = null; Store.del('sk_logo'); draw(); }
      if (a === 'export') {
        read(); saveAll();
        const data = JSON.stringify({ app: 'sekolify-licences', version: 1, exported_at: new Date().toISOString(), settings, logo, licences }, null, 1);
        shareFile(`sekolify-sauvegarde-${new Date().toISOString().slice(0, 10)}.json`, new TextEncoder().encode(data), 'application/json', 'Sauvegarde Sekolify');
      }
      if (a === 'wipe') {
        const ok = await ask({ title: 'Tout effacer ?', text: 'Écoles, licences, réglages ET clé privée seront supprimés de cet appareil. Irréversible.', ok: 'Tout effacer', danger: true });
        if (ok) { licences = []; logo = null; settings = { ...DEFAULTS }; Store.del('sk_licences'); Store.del('sk_settings'); Store.del('sk_logo'); Store.del('sk_pub'); await KS.clear(); pubB64 = ''; applyTheme(); api.close(); showSetup(); }
      }
    });
    ov.addEventListener('change', async (e) => {
      const f = e.target.files && e.target.files[0]; if (!f) return;
      if (e.target.id === 's-logo') {
        try {
          const url = await readDataURL(f);
          const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
          const s = Math.min(1, 400 / Math.max(img.width, img.height)), c = document.createElement('canvas');
          c.width = Math.round(img.width * s); c.height = Math.round(img.height * s); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          read(); logo = c.toDataURL('image/png'); Store.set('sk_logo', logo); draw();
        } catch (ex) { toast('Image illisible'); }
      }
      if (e.target.id === 's-import') {
        try {
          const j = JSON.parse(await readText(f));
          if (j.app !== 'sekolify-licences' || !Array.isArray(j.licences)) throw new Error('bad');
          const ok = await ask({ title: 'Importer cette sauvegarde ?', text: `${j.licences.length} école(s). Les données actuelles seront remplacées.`, ok: 'Remplacer', danger: true });
          if (!ok) return;
          licences = j.licences; settings = { ...DEFAULTS, ...j.settings }; logo = j.logo || null; Store.set('sk_logo', logo); saveAll(); applyTheme(); renderAll(); api.close(); toast('Sauvegarde importée');
        } catch (ex) { toast('Fichier de sauvegarde invalide'); }
      }
    });
  } });
}

$('#fab').addEventListener('click', () => openForm());
$('#btn-settings').addEventListener('click', openSettings);

/* Bouton retour Android : ferme la feuille ouverte */
document.addEventListener('DOMContentLoaded', () => {
  const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
  if (App && App.addListener) App.addListener('backButton', () => {
    if (stack.length) stack[stack.length - 1].close();
    else if (!$('#searchbar').hidden) { $('#btn-search').click(); }
    else App.exitApp();
  });
});

/* ================= Démarrage ================= */
(async () => {
  applyTheme();
  if (!window.crypto || !crypto.subtle) { document.body.innerHTML = '<p style="padding:30px">WebCrypto indisponible sur cet appareil.</p>'; return; }
  try { (await KS.hasSeed()) ? showDash() : showSetup(); } catch (e) { showSetup(); }
})();
})();
