/* Ed25519 (RFC 8032) — signature uniquement, BigInt + WebCrypto SHA-512.
 * Produit les mêmes signatures que cryptography.hazmat (Ed25519 est déterministe). */
(function (root) {
  'use strict';
  const P = 2n ** 255n - 19n;
  const L = 2n ** 252n + 27742317777372353535851937790883648493n;

  const mod = (a, m = P) => { const r = a % m; return r >= 0n ? r : r + m; };
  function pow(b, e, m = P) {
    let r = 1n; b = mod(b, m);
    while (e > 0n) { if (e & 1n) r = (r * b) % m; b = (b * b) % m; e >>= 1n; }
    return r;
  }
  const inv = (a) => pow(a, P - 2n);
  const D = mod(-121665n * inv(121666n));
  const SQRT_M1 = pow(2n, (P - 1n) / 4n);

  function recoverX(y, sign) {
    const y2 = (y * y) % P;
    const x2 = mod((y2 - 1n) * inv(D * y2 + 1n));
    if (x2 === 0n) return sign ? null : 0n;
    let x = pow(x2, (P + 3n) / 8n);
    if (mod(x * x - x2) !== 0n) x = (x * SQRT_M1) % P;
    if (mod(x * x - x2) !== 0n) return null;
    if ((x & 1n) !== BigInt(sign)) x = P - x;
    return x;
  }
  const GY = mod(4n * inv(5n));
  const GX = recoverX(GY, 0);
  const G = [GX, GY, 1n, (GX * GY) % P];

  function add(p, q) {
    const A = mod((p[1] - p[0]) * (q[1] - q[0]));
    const B = mod((p[1] + p[0]) * (q[1] + q[0]));
    const C = mod(2n * p[3] * q[3] * D);
    const Dd = mod(2n * p[2] * q[2]);
    const E = B - A, F = Dd - C, Gg = Dd + C, H = B + A;
    return [mod(E * F), mod(Gg * H), mod(F * Gg), mod(E * H)];
  }
  function mul(s, p) {
    let q = [0n, 1n, 1n, 0n];
    while (s > 0n) { if (s & 1n) q = add(q, p); p = add(p, p); s >>= 1n; }
    return q;
  }

  function leToBig(b) { let n = 0n; for (let i = b.length - 1; i >= 0; i--) n = (n << 8n) | BigInt(b[i]); return n; }
  function bigToLe(n, len) { const o = new Uint8Array(len); for (let i = 0; i < len; i++) { o[i] = Number(n & 0xffn); n >>= 8n; } return o; }
  function encodePoint(p) {
    const zi = inv(p[2]);
    const x = (p[0] * zi) % P, y = (p[1] * zi) % P;
    return bigToLe(y | ((x & 1n) << 255n), 32);
  }
  function concat(...arrs) {
    const out = new Uint8Array(arrs.reduce((n, a) => n + a.length, 0));
    let o = 0; for (const a of arrs) { out.set(a, o); o += a.length; }
    return out;
  }
  async function sha512(...parts) {
    return new Uint8Array(await crypto.subtle.digest('SHA-512', concat(...parts)));
  }
  function expand(h) {
    const a = h.slice(0, 32);
    a[0] &= 248; a[31] &= 127; a[31] |= 64;
    return { a: leToBig(a), prefix: h.slice(32, 64) };
  }

  async function getPublicKey(seed) {
    const { a } = expand(await sha512(seed));
    return encodePoint(mul(a, G));
  }
  async function sign(msg, seed) {
    const { a, prefix } = expand(await sha512(seed));
    const A = encodePoint(mul(a, G));
    const r = leToBig(await sha512(prefix, msg)) % L;
    const R = encodePoint(mul(r, G));
    const k = leToBig(await sha512(R, A, msg)) % L;
    const S = (r + k * a) % L;
    return concat(R, bigToLe(S, 32));
  }

  /* PKCS#8 PEM (celui de private_key.pem) -> seed de 32 octets */
  const PKCS8_PREFIX = [0x30, 0x2e, 0x02, 0x01, 0x00, 0x30, 0x05, 0x06, 0x03, 0x2b, 0x65, 0x70, 0x04, 0x22, 0x04, 0x20];
  function parsePem(text) {
    if (/ENCRYPTED PRIVATE KEY/.test(text)) throw new Error('Cette clé est protégée par un mot de passe. Utilise une clé sans mot de passe.');
    if (/BEGIN PUBLIC KEY/.test(text)) throw new Error('C’est une clé publique. Il faut le fichier private_key.pem (clé privée).');
    const m = text.match(/-----BEGIN PRIVATE KEY-----([\s\S]+?)-----END PRIVATE KEY-----/);
    if (!m) throw new Error('Fichier invalide : bloc « BEGIN PRIVATE KEY » introuvable.');
    let bin;
    try { bin = atob(m[1].replace(/\s+/g, '')); } catch (e) { throw new Error('Fichier invalide : Base64 illisible.'); }
    const der = Uint8Array.from(bin, (c) => c.charCodeAt(0));
    if (der.length !== 48 || PKCS8_PREFIX.some((v, i) => der[i] !== v)) {
      throw new Error('Ce n’est pas une clé privée Ed25519.');
    }
    return der.slice(16);
  }

  const api = { sign, getPublicKey, parsePem };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Ed25519 = api;
})(typeof self !== 'undefined' ? self : globalThis);
